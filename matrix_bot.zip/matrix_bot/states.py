from aiogram.dispatcher.filters.state import StatesGroup, State


class UserStates(StatesGroup):
    wait_for_buy = State()
    wait_for_buy_sotka = State()
    confirm_buy = State()
    confirm_sotka_buy = State()
    sotka_clone_buy = State()
    confirm_clone_buy = State()
    confirm_sotka_clone_buy = State()
    get_users_mailing_message = State()
    get_admin_mailing_message = State()
    confirm_mailing = State()
    clone_choose_state = State()