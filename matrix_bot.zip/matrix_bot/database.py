import asyncpg
from datetime import datetime

import config
from asyncpg.exceptions import UniqueViolationError, DataError
from asyncpg.pool import Pool
from typing import Union
from config import db_name, db_host, db_user, db_pass, admins


class DataBase:
    def __init__(self):
        self.pool: Union[Pool, None] = None

    async def create_pool(self):
        self.pool = await asyncpg.create_pool(user=db_user, host=db_host, database=db_name,
                                              password=db_pass, max_inactive_connection_lifetime=0)

    async def create_tables(self):
        sql = "CREATE TABLE IF NOT EXISTS users(id serial, user_id bigint unique, username text, demo_balance integer," \
              "withdraw_balance integer, cumulative_balance integer, demo_cumulative_balance integer," \
              "inviter bigint, balance_total_earned integer, balance_net_earned integer, join_date date, expclone_date timestamp," \
              "demo_level int, classic_level int, sotka_level int);" \
              "CREATE TABLE IF NOT EXISTS sotka_table(id serial, user_id bigint unique, level integer, purchase_date date);" \
              "CREATE TABLE IF NOT EXISTS referrals(id serial, user_id bigint, referral_id bigint unique);" \
              "CREATE TABLE IF NOT EXISTS clones(user_id bigint, clone_id serial, matrix_type text, matrix_level int," \
              "clone_serial_number int);" \
              "CREATE TABLE IF NOT EXISTS money_box(amount int unique);" \
              ""
        for i in range(1, 6):
            if i % 2 == 0:
                sql += f"CREATE TABLE IF NOT EXISTS classic_level_{i}(id serial, user_id bigint unique, partner1 bigint, partner2 bigint," \
                       f"partner3 bigint);"
                sql += f"CREATE TABLE IF NOT EXISTS demo_level_{i}(id serial, user_id bigint unique, partner1 bigint, partner2 bigint," \
                       f" partner3 bigint);"
            else:
                sql += f"CREATE TABLE IF NOT EXISTS classic_level_{i}(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);"
                sql += f"CREATE TABLE IF NOT EXISTS demo_level_{i}(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);"
            sql += "CREATE TABLE IF NOT EXISTS sotka_level_1(id serial, user_id bigint unique, partner1 bigint, partner2 bigint, partner3 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_2(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_3(id serial, user_id bigint unique, partner1 bigint, partner2 bigint, partner3 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_4(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_5(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_6(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_7(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_8(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_9(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_10(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);"
        await self.pool.execute(sql)
        await self.create_money_box()

    async def add_user(self, user_id: int, username: str, inviter=None):
        today = datetime.today()
        try:
            await self.pool.execute("INSERT INTO users(user_id, username, demo_balance, withdraw_balance,"
                              "cumulative_balance, demo_cumulative_balance, inviter, balance_total_earned, balance_net_earned,"
                              "join_date, expclone_date, demo_level, classic_level, sotka_level) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)",
                              user_id, username, 999999, 999999, 0, 0, inviter, 0, 0, today.date(), today, 0, 0, 0)
        except UniqueViolationError:
            pass

    async def add_referral(self, user_id: int, referral_id: int):
        try:
            await self.pool.execute("INSERT INTO referrals(user_id, referral_id) VALUES($1, $2)",
                                    user_id, referral_id)
        except UniqueViolationError:
            pass

    async def is_user_exists(self, user_id: int) -> bool:
        result = await self.pool.fetch("SELECT * FROM users WHERE user_id=$1",
                                       user_id)
        if result:
            return True
        else:
            return False

    async def get_referrer(self, user_id: int) -> int:
        result = await self.pool.fetchval("SELECT inviter FROM users WHERE user_id=$1",
                                          user_id)
        return result

    async def get_demo_level(self, user_id: int) -> int:
        result = await self.pool.fetchval("SELECT demo_level FROM users WHERE user_id=$1",
                                          user_id)
        return result

    async def get_classic_level(self, user_id: int) -> int:
        result = await self.pool.fetchrow("SELECT classic_level FROM users WHERE user_id=$1",
                                          user_id)
        return result

    async def get_user(self, user_id: int) -> list:
        result = await self.pool.fetchrow("SELECT * FROM users WHERE user_id=$1",
                                          user_id)
        return result

    async def get_ref_count(self, user_id: int) -> int:
        result = await self.pool.fetchval("SELECT COUNT(*) FROM referrals WHERE user_id=$1",
                                          user_id)
        return result

    async def add_user_to_demo_matrix(self, level: int, user_id: int, partner_id: int) -> None:
        if user_id != partner_id:
            if level % 2 == 0:
                sql = f"""UPDATE demo_level_{level} SET 
                partner1 = CASE WHEN partner1 IS NULL THEN {partner_id} ELSE partner1 END,
                partner2 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NULL THEN {partner_id} ELSE partner2 END,
                partner3 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NOT NULL AND partner3 IS NULL THEN {partner_id} ELSE partner3 END
                WHERE user_id = {user_id};"""
            else:
                sql = f"""UPDATE demo_level_{level} SET 
                partner1 = CASE WHEN partner1 IS NULL THEN {partner_id} ELSE partner1 END,
                partner2 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NULL THEN {partner_id} ELSE partner2 END
                WHERE user_id = {user_id};"""
            await self.pool.execute(sql)
            try:
                await self.pool.execute(f"INSERT INTO demo_level_{level}(user_id) VALUES($1)", partner_id)
            except UniqueViolationError:
                pass

    async def update_user_after_buy(self, user_id: int, level: int, level_price: int, matrix_type: str):
        user_level = await self.get_user_level(user_id, matrix_type)
        if user_level >= level:
            return
        if matrix_type == 'demo':
            sql = 'UPDATE users SET demo_balance=demo_balance-$3, demo_level=$2 WHERE user_id=$1'
        else:
            sql = f'UPDATE users SET withdraw_balance=withdraw_balance-$3, {matrix_type}_level=$2 WHERE user_id=$1'
        await self.pool.execute(sql, user_id, level, level_price)

    async def get_user_balance(self, user_id: int, matrix_type: str):
        if matrix_type == 'demo':
            result = await self.pool.fetchval("SELECT demo_balance FROM users WHERE user_id=$1", user_id)
        else:
            result = await self.pool.fetchval("SELECT withdraw_balance FROM users WHERE user_id=$1", user_id)
        return result

    async def add_admin_to_matrix(self, admin_id: int):
        for i in range(1, 6):
            classic_sql = f"INSERT INTO classic_level_{i}(user_id) VALUES($1)"
            demo_sql = f"INSERT INTO demo_level_{i}(user_id) VALUES($1)"
            try:
                await self.pool.execute(demo_sql, admin_id)
                await self.pool.execute(classic_sql, admin_id)
            except UniqueViolationError:
                pass
        await self.pool.execute("UPDATE users SET demo_level=1, classic_level=1, sotka_level=10 WHERE user_id=$1",
                                admin_id)
        for i in range(1, 11):
            sql = f"INSERT INTO sotka_level_{i}(user_id) VALUES($1)"
            try:
                await self.pool.execute(sql, admin_id)
            except UniqueViolationError:
                pass

    async def get_empty_place(self, level: int, matrix_type: str):
        if matrix_type == 'demo':
            sql = f"""SELECT user_id FROM demo_level_{level} 
            WHERE partner1 IS NULL OR partner2 IS NULL """
        else:
            sql = f"""SELECT user_id FROM classic_level_{level} 
            WHERE partner1 IS NULL OR partner2 IS NULL """
        if level % 2 != 0:
            sql += "ORDER BY id LIMIT 1;"
        else:
            sql += "OR partner3 IS NULL ORDER BY id LIMIT 1;"
        result = await self.pool.fetchval(sql)
        if result:
            return result
        else:
            return 0

    async def is_user_exists_in_demo_matrix(self, user_id: int, matrix_level: int) -> bool:
        result = await self.pool.fetch(f"SELECT * FROM demo_level_{matrix_level} WHERE user_id=$1", user_id)
        if result:
            return True
        else:
            return False

    async def get_demo_matrix_places(self, user_id: int) -> int:
        result = await self.pool.fetchval("""SELECT COUNT(*) as user_1_count
        FROM (
        SELECT user_id FROM demo_level_1 WHERE user_id = $1
        UNION ALL
        SELECT user_id FROM demo_level_2 WHERE user_id = $1
        UNION ALL
        SELECT user_id FROM demo_level_3 WHERE user_id = $1
        UNION ALL
        SELECT user_id FROM demo_level_4 WHERE user_id = $1
        UNION ALL
        SELECT user_id FROM demo_level_5 WHERE user_id = $1) subquery;""", user_id)
        return result

    async def get_classic_matrix_places(self, user_id: int) -> int:
        result = await self.pool.fetchval("""SELECT COUNT(*) as user_1_count
        FROM (
        SELECT user_id FROM classic_level_1 WHERE user_id = $1
        UNION ALL
        SELECT user_id FROM classic_level_2 WHERE user_id = $1
        UNION ALL
        SELECT user_id FROM classic_level_3 WHERE user_id = $1
        UNION ALL
        SELECT user_id FROM classic_level_4 WHERE user_id = $1
        UNION ALL
        SELECT user_id FROM classic_level_5 WHERE user_id = $1) subquery;""", user_id)
        return result

    async def is_demo_matrix_complete(self, user_id: int, matrix_level: int) -> bool:
        if matrix_level % 2 != 0:
            sql = f"""SELECT user_id FROM demo_level_{matrix_level} WHERE user_id=$1
             GROUP BY user_id
             HAVING COUNT(*) = COUNT(partner1) AND COUNT(*) = COUNT(partner2);"""
        else:
            sql = f"""SELECT user_id FROM demo_level_{matrix_level} WHERE user_id=$1
                 GROUP BY user_id
                 HAVING COUNT(*) = COUNT(partner1) AND COUNT(*) = COUNT(partner2) AND COUNT(*) = COUNT(partner3);"""
        result = await self.pool.fetchval(sql, user_id)
        if result:
            return True
        else:
            return False

    async def update_matrix_level(self, user_id: int, matrix_level: int, matrix_type: str):
        user_level = await self.get_user_level(user_id, matrix_type)
        try:
            if user_level >= matrix_level:
                return
        except TypeError:
            return
        await self.pool.execute(f"UPDATE users SET {matrix_type}_level=$1 WHERE user_id=$2",
                                matrix_level, user_id)
        if matrix_type == 'sotka':
            return
        if matrix_level < 5:
            try:
                await self.pool.execute(f"INSERT INTO {matrix_type}_level_{matrix_level}(user_id) "
                                        f"VALUES ($1)", user_id)
            except UniqueViolationError:
                pass

    async def increase_demo_cum_balance(self, user_id: int, amount: int) -> None:
        await self.pool.execute("UPDATE users SET demo_cumulative_balance=demo_cumulative_balance+$1 "
                                "WHERE user_id=$2", amount, user_id)

    async def decrease_demo_cum_balance(self, user_id: int, amount: int) -> None:
        await self.pool.execute("UPDATE users SET demo_cumulative_balance=demo_cumulative_balance-$1 "
                                "WHERE user_id=$2", amount, user_id)

    async def increase_demo_balance(self, user_id: int, amount: int) -> None:
        await self.pool.execute("UPDATE users SET demo_balance=demo_balance+$1 "
                                "WHERE user_id=$2", amount, user_id)

    async def get_last_filled_column(self, user_id: int, matrix_level: int, matrix_type: str) -> str:
        if matrix_level % 2 != 0:
            sql = f"""SELECT user_id,
            CASE
            WHEN partner2 IS NOT NULL THEN 'partner2'
            WHEN partner1 IS NOT NULL THEN 'partner1'
            END AS last_filled_column
            FROM {matrix_type}_level_{matrix_level} WHERE user_id=$1;"""
        else:
            sql = f"""
            SELECT user_id, 
            CASE 
            WHEN partner3 IS NOT NULL THEN 'partner3'
            WHEN partner2 IS NOT NULL THEN 'partner2'
            WHEN partner1 IS NOT NULL THEN 'partner1'
            END AS last_filled_column
            FROM {matrix_type}_level_{matrix_level}
            WHERE user_id = $1;"""
        result = await self.pool.fetchrow(sql, user_id)
        return result['last_filled_column']

    async def get_all_referrals(self, user_id: int) -> list:
        result = await self.pool.fetch('SELECT referral_id FROM referrals WHERE user_id=$1',
                                       user_id)
        return result

    async def get_demo_activated_referrals(self, referrals_list: list) -> int:
        query = 'SELECT COUNT(*) from demo_level_1 WHERE user_id IN ({})'.format(
            ','.join(['${}'.format(i + 1) for i in range(len(referrals_list))]))
        result = await self.pool.fetchval(query, *referrals_list)
        return result

    async def get_classic_activated_referrals(self, referrals_list: list) -> int:
        query = 'SELECT COUNT(*) from classic_level_1 WHERE user_id IN ({})'.format(
            ','.join(['${}'.format(i + 1) for i in range(len(referrals_list))]))
        result = await self.pool.fetchval(query, *referrals_list)
        return result

    async def add_clone(self, user_id: int, matrix_type: str, matrix_level: int):
        serial_number = await self.pool.fetchval("select count(*) from clones where user_id=$1", user_id)
        result = await self.pool.fetchval("INSERT INTO clones(user_id, matrix_type, matrix_level, clone_serial_number) "
                                          "VALUES ($1, $2, $3, $4) RETURNING clone_id", user_id,
                                          matrix_type, matrix_level, serial_number+1)
        if matrix_type != 'sotka':
            await self.update_clone_date(user_id)
        return result

    async def update_clone_date(self, user_id):
        await self.pool.execute("UPDATE users SET expclone_date=date_trunc('day', expclone_date) + INTERVAL '1 day' "
                                "WHERE user_id = $1", user_id)

    async def get_clone_date(self, user_id):
        result = await self.pool.fetchval("SELECT expclone_date FROM users WHERE user_id=$1" ,
                                          user_id)
        return result

    async def get_partners_from_matrix(self, matrix_level: int, user_id: int, matrix_type: str):
        if matrix_type in ('classic', 'demo'):
            if matrix_level % 2 != 0:
                result = await self.pool.fetch(f"SELECT partner1, partner2 FROM {matrix_type}_level_{matrix_level} WHERE (partner1 IS NOT NULL OR partner2 IS NOT NULL) AND "
                                               f"user_id=$1;", user_id)
            else:
                result = await self.pool.fetch(f"SELECT partner1, partner2, partner3 "
                                                  f"FROM {matrix_type}_level_{matrix_level} WHERE (partner1 IS NOT NULL OR partner2 IS NOT NULL or partner3 "
                                                  f"IS NOT NULL) and user_id=$1;", user_id)
        else:
            if matrix_level not in (1, 3):
                result = await self.pool.fetch(f"SELECT partner1, partner2 FROM {matrix_type}_level_{matrix_level} WHERE (partner1 IS NOT NULL OR partner2 IS NOT NULL) AND "
                                               f"user_id=$1;", user_id)
            else:
                result = await self.pool.fetch(f"SELECT partner1, partner2, partner3 "
                                                  f"FROM {matrix_type}_level_{matrix_level} WHERE (partner1 IS NOT NULL OR partner2 IS NOT NULL or partner3 "
                                                  f"IS NOT NULL) and user_id=$1;", user_id)
        return result

    async def user_in_demo_matrix(self, user_id: int, matrix_level: int) -> bool:
        result = await self.pool.fetchrow(f"SELECT * FROM demo_level_{matrix_level} WHERE user_id=$1",
                                          user_id)
        if result:
            return True
        else:
            return False

    async def get_clone_from_matrix(self, clone_id: int):
        result = await self.pool.fetchval("SELECT user_id FROM clones WHERE clone_id=$1", clone_id)
        return result

    async def get_next_partners_from_matrix(self, user_id: int, matrix_level: int, matrix_type: str):
        if matrix_type in ('classic', 'demo'):
            if matrix_level % 2 != 0:
                result = await self.pool.fetch(f"SELECT partner1, partner2 FROM {matrix_type}_level_{matrix_level} "
                                                  f"WHERE id > (SELECT id FROM {matrix_type}_level_{matrix_level} "
                                                  f"WHERE user_id = $1) AND partner1 is not null "
                                                  f"ORDER BY user_id LIMIT 2;", user_id)
            else:
                result = await self.pool.fetch(f"SELECT partner1, partner2, partner3 FROM {matrix_type}_level_{matrix_level} "
                                                  f"WHERE id > (SELECT id FROM {matrix_type}_level_{matrix_level} "
                                                  f"WHERE user_id = $1) AND partner1 is not null "
                                                  f"ORDER BY user_id LIMIT 6;", user_id)
        else:
            if matrix_level not in (1, 3):
                result = await self.pool.fetch(f"SELECT partner1, partner2 FROM {matrix_type}_level_{matrix_level} "
                                                  f"WHERE id > (SELECT id FROM {matrix_type}_level_{matrix_level} "
                                                  f"WHERE user_id = $1) AND partner1 is not null "
                                                  f"ORDER BY user_id LIMIT 2;", user_id)
            else:
                result = await self.pool.fetch(f"SELECT partner1, partner2, partner3 FROM {matrix_type}_level_{matrix_level} "
                                                  f"WHERE id > (SELECT id FROM {matrix_type}_level_{matrix_level} "
                                                  f"WHERE user_id = $1) AND partner1 is not null "
                                                  f"ORDER BY user_id LIMIT 2;", user_id)
        return result

    async def is_user_exists_in_classic_matrix(self, user_id, matrix_level):
        result = await self.pool.fetch(f"SELECT * FROM classic_level_{matrix_level} WHERE user_id=$1", user_id)
        if result:
            return True
        else:
            return False

    async def is_classic_matrix_complete(self, user_id, matrix_level):
        sql = f"""SELECT user_id FROM classic_level_{matrix_level} WHERE user_id=$1
         GROUP BY user_id
         HAVING COUNT(*) = COUNT(partner1) AND COUNT(*) = COUNT(partner2);"""
        result = await self.pool.fetchval(sql, user_id)
        if result:
            return True
        else:
            return False

    async def add_user_to_classic_matrix(self, level: int, user_id: int, partner_id: int):
        if user_id != partner_id:
            if level % 2 == 0:
                sql = f"""UPDATE classic_level_{level} SET 
                partner1 = CASE WHEN partner1 IS NULL THEN {partner_id} ELSE partner1 END,
                partner2 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NULL THEN {partner_id} ELSE partner2 END,
                partner3 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NOT NULL AND partner3 IS NULL THEN {partner_id} ELSE partner3 END
                WHERE user_id = {user_id};"""
            else:
                sql = f"""UPDATE classic_level_{level} SET 
                partner1 = CASE WHEN partner1 IS NULL THEN {partner_id} ELSE partner1 END,
                partner2 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NULL THEN {partner_id} ELSE partner2 END
                WHERE user_id = {user_id};"""
            await self.pool.execute(sql)
            try:
                await self.pool.execute(f"INSERT INTO classic_level_{level}(user_id) VALUES($1)", partner_id)
            except UniqueViolationError:
                pass

    async def increase_classic_cum_balance(self, user_id: int, amount: int) -> None:
        await self.pool.execute("UPDATE users SET cumulative_balance=cumulative_balance+$1 "
                                "WHERE user_id=$2", amount, user_id)

    async def increase_classic_balance(self, user_id: int, amount: int) -> None:
        await self.pool.execute("UPDATE users SET withdraw_balance=withdraw_balance+$1, balance_total_earned=balance_total_earned+$1 "
                                "WHERE user_id=$2", amount, user_id)

    async def is_classic_matrix_complete(self, user_id: int, matrix_level: int) -> bool:
        if matrix_level % 2 != 0:
            sql = f"""SELECT user_id FROM classic_level_{matrix_level} WHERE user_id=$1
             GROUP BY user_id
             HAVING COUNT(*) = COUNT(partner1) AND COUNT(*) = COUNT(partner2);"""
        else:
            sql = f"""SELECT user_id FROM classic_level_{matrix_level} WHERE user_id=$1
             GROUP BY user_id
             HAVING COUNT(*) = COUNT(partner1) AND COUNT(*) = COUNT(partner2) AND COUNT(*) = COUNT(partner3);"""
        result = await self.pool.fetchval(sql, user_id)
        if result:
            return True
        else:
            return False

    async def decrease_classic_cum_balance(self, user_id: int, amount: int) -> None:
        await self.pool.execute("UPDATE users SET cumulative_balance=cumulative_balance-$1 "
                                "WHERE user_id=$2", amount, user_id)

    async def get_referrals_by_level(self, user_id: int, level: int):
        sql = """WITH RECURSIVE referrals AS (
        SELECT user_id, inviter, 1 AS level
        FROM users
        WHERE user_id = $1
        UNION ALL
        SELECT u.user_id, u.inviter, r.level + 1
        FROM users u
        JOIN referrals r ON u.inviter = r.user_id
        WHERE r.level < $2 AND u.user_id <> $3)
        SELECT * FROM referrals
        ORDER BY level, user_id;
        """
        return await self.pool.fetch(sql, user_id, level, admins[0])

    async def get_sotka_level(self, user_id: int):
        return await self.pool.fetchval("SELECT sotka_level FROM users WHERE user_id=$1", user_id)

    async def get_empty_place_from_sotka(self, level, user_id, main_user_id):
        if level in (1, 3):
            sql = f"""SELECT user_id FROM sotka_level_{level} 
            WHERE (partner1 IS NULL OR partner2 IS NULL OR partner3 IS NULL) and user_id=$1 ORDER BY id LIMIT 1;"""
        else:
            sql = f"""SELECT user_id FROM sotka_level_{level} 
            WHERE (partner1 IS NULL OR partner2 IS NULL) and user_id=$1 ORDER BY id LIMIT 1;"""
        result = await self.pool.fetchval(sql, user_id)
        if result:
            return result
        else:
            clones = await self.get_clones('sotka', level, main_user_id, 100)
            for c in clones:
                result = await self.pool.fetchval(sql, c['clone_id'])
                if result:
                    return result
            if level in (1, 3):
                sql = f"""WITH RECURSIVE partners_cte AS (
                      SELECT user_id, partner1, partner2, partner3
                      FROM sotka_level_1
                      WHERE user_id = $1
                    
                      UNION
                    
                      SELECT sotka_level_1.user_id, sotka_level_1.partner1, sotka_level_1.partner2, sotka_level_1.partner3
                      FROM sotka_level_1
                      JOIN partners_cte ON
                        (sotka_level_1.user_id = partners_cte.partner1 OR
                        sotka_level_1.user_id = partners_cte.partner2 OR
                        sotka_level_1.user_id = partners_cte.partner3 OR
                        partners_cte.partner1 IS NULL OR
                        partners_cte.partner2 IS NULL OR
                        partners_cte.partner3 IS NULL)
                    )
                    SELECT user_id
                    FROM partners_cte
                    WHERE user_id != $1
                    limit 1;"""
            else:
                sql = f"""WITH RECURSIVE partners_cte AS (
                  SELECT user_id, partner1, partner2
                  FROM sotka_level_1
                  WHERE user_id = $1

                  UNION

                  SELECT sotka_level_1.user_id, sotka_level_1.partner1, sotka_level_1.partner2
                  FROM sotka_level_1
                  JOIN partners_cte ON
                    (sotka_level_1.user_id = partners_cte.partner1 OR
                    sotka_level_1.user_id = partners_cte.partner2 OR
                    partners_cte.partner1 IS NULL OR
                    partners_cte.partner2 IS NULL)
                )
                SELECT user_id
                FROM partners_cte
                WHERE user_id != $1
                limit 1;"""
            result = await self.pool.fetchval(sql, user_id)
            if result:
                return result
            if level in (1, 3):
                sql = f"""SELECT user_id FROM sotka_level_{level} 
                WHERE (partner1 IS NULL OR partner2 IS NULL OR partner3 IS NULL) ORDER BY id LIMIT 1;"""
            else:
                sql = f"""SELECT user_id FROM sotka_level_{level} 
                WHERE (partner1 IS NULL OR partner2 IS NULL) ORDER BY id LIMIT 1;"""
            result = await self.pool.fetchval(sql)
            return result

    async def get_last_filled_column_sotka(self, user_id: int, matrix_level: int) -> str:
        if matrix_level not in (1, 3):
            sql = f"""SELECT user_id,
                   CASE
                   WHEN partner2 IS NOT NULL THEN 'partner2'
                   WHEN partner1 IS NOT NULL THEN 'partner1'
                   END AS last_filled_column
                   FROM sotka_level_{matrix_level} WHERE user_id=$1;"""
        else:
            sql = f"""
                   SELECT user_id, 
                   CASE 
                   WHEN partner3 IS NOT NULL THEN 'partner3'
                   WHEN partner2 IS NOT NULL THEN 'partner2'
                   WHEN partner1 IS NOT NULL THEN 'partner1'
                   END AS last_filled_column
                   FROM sotka_level_{matrix_level}
                   WHERE user_id = $1;"""
        result = await self.pool.fetchrow(sql, user_id)
        return result['last_filled_column']

    async def add_user_to_sotka_matrix(self, level: int, user_id: int, partner_id: int):
        if user_id != partner_id:
            if level in (1, 3):
                sql = f"""UPDATE sotka_level_{level} SET 
                   partner1 = CASE WHEN partner1 IS NULL THEN {partner_id} ELSE partner1 END,
                   partner2 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NULL THEN {partner_id} ELSE partner2 END,
                   partner3 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NOT NULL AND partner3 IS NULL THEN {partner_id} ELSE partner3 END
                   WHERE user_id = {user_id};"""
            else:
                sql = f"""UPDATE sotka_level_{level} SET 
                   partner1 = CASE WHEN partner1 IS NULL THEN {partner_id} ELSE partner1 END,
                   partner2 = CASE WHEN partner1 IS NOT NULL AND partner2 IS NULL THEN {partner_id} ELSE partner2 END
                   WHERE user_id = {user_id};"""
            await self.pool.execute(sql)
        try:
            await self.pool.execute(f"INSERT INTO sotka_level_{level}(user_id) VALUES($1)", partner_id)
        except UniqueViolationError:
            pass

    async def is_sotka_matrix_complete(self, user_id: int, matrix_level: int) -> bool:
        if matrix_level not in (1, 3):
            sql = f"""SELECT user_id FROM sotka_level_{matrix_level} WHERE user_id=$1
             GROUP BY user_id
             HAVING COUNT(*) = COUNT(partner1) AND COUNT(*) = COUNT(partner2);"""
        else:
            sql = f"""SELECT user_id FROM sotka_level_{matrix_level} WHERE user_id=$1
                 GROUP BY user_id
                 HAVING COUNT(*) = COUNT(partner1) AND COUNT(*) = COUNT(partner2) AND COUNT(*) = COUNT(partner3);"""
        result = await self.pool.fetchval(sql, user_id)
        if result:
            return True
        else:
            return False

    async def create_money_box(self):
        row_count = await self.pool.fetchval("SELECT COUNT(*) FROM money_box")
        if row_count == 0:
            await self.pool.execute("INSERT INTO money_box(amount) VALUES($1)", 0)

    async def add_money_to_box(self, amount: int):
        await self.pool.execute("UPDATE money_box SET amount=amount+$1", amount)

    async def get_user_by_clone(self, clone_id: int):
        return await self.pool.fetchval("SELECT user_id FROM clones WHERE clone_id=$1", clone_id)

    async def get_user_level(self, user_id: int, matrix_type: str) -> int:
        return await self.pool.fetchval(f"SELECT {matrix_type}_level FROM users WHERE user_id=$1",
                                        user_id)

    async def get_clones(self, matrix_type: str, matrix_level: int, user_id: int, limit: int):
        result = await self.pool.fetch("SELECT * FROM clones WHERE matrix_type=$1 AND matrix_level=$2 "
                                       f"AND user_id=$3 LIMIT {limit}",
                                       matrix_type, matrix_level, user_id)
        return result

    async def get_all_users(self):
        result = await self.pool.fetch("SELECT * FROM users")
        return result

    async def get_money_from_box(self):
        return await self.pool.fetchval("SELECT amount FROM money_box")

    async def remove_money_from_box(self, amount: int) -> None:
        await self.pool.execute("UPDATE money_box SET amount=amount-$1", amount)

    async def get_active_referrals(self, user_id):
        result = await self.pool.fetch("SELECT s.user_id FROM sotka_level_1 s "
                                          "JOIN referrals r ON s.user_id = r.referral_id "
                                          "WHERE r.user_id = $1", user_id)
        return result

    async def decrease_withdraw_balance(self, user_id: int, amount: int):
        await self.pool.execute("UPDATE users SET withdraw_balance=withdraw_balance-$1 WHERE user_id=$2", amount, user_id)

    async def update_sotka_level(self, user_id: int, level: int):
        if level > 10:
            return
        if user_id == config.admins[0]:
            return
        await self.pool.execute("UPDATE users SET sotka_level=$1 WHERE user_id=$2", level, user_id)

    async def get_clone_number(self, clone_id: int) -> int:
        try:
            result = await self.pool.fetchval("SELECT clone_serial_number FROM clones WHERE clone_id=$1", clone_id)
            if result:
                return result
            else:
                return -1
        except DataError:
            return -1

    async def get_total_earned(self, user_id: int) -> int:
        return await self.pool.fetchval("SELECT balance_total_earned FROM users WHERE user_id=$1", user_id)

    async def get_topper_place(self, place_id: int, matrix_type: str, matrix_level: int):
        if matrix_type in ('demo', 'classic'):
            if matrix_level % 2 == 0:
                sql = f"SELECT user_id FROM {matrix_type}_level_{matrix_level} WHERE partner1={place_id} OR partner2={place_id} OR partner3={place_id}"
            else:
                sql = f"SELECT user_id FROM {matrix_type}_level_{matrix_level} WHERE partner1={place_id} OR partner2={place_id}"
        else:
            if matrix_level in (1, 3):
                sql = f"SELECT user_id FROM {matrix_type}_level_{matrix_level} WHERE partner1={place_id} OR partner2={place_id} OR partner3={place_id}"
            else:
                sql = f"SELECT user_id FROM {matrix_type}_level_{matrix_level} WHERE partner1={place_id} OR partner2={place_id}"
        result = await self.pool.fetchval(sql)
        if result:
            return result
        else:
            return config.admins[0]

    async def update_clone_level(self, clone_id: int, level: int):
        await self.pool.execute("UPDATE clones SET matrix_level=$1 WHERE clone_id=$2", level, clone_id)

    async def get_closed_places(self, user_id: int, matrix_type: str, matrix_level: int):
        if matrix_type in ('demo', 'classic'):
            if matrix_level % 2 != 0:
                sql = "SELECT (CASE WHEN partner1 IS NOT NULL THEN 1 ELSE 0 END +" \
                      "CASE WHEN partner2 IS NOT NULL THEN 1 ELSE 0 END) AS filled_count " \
                      f"FROM {matrix_type}_level_{matrix_level} WHERE user_id=$1;"
            else:
                sql = "SELECT (CASE WHEN partner1 IS NOT NULL THEN 1 ELSE 0 END +" \
                      "CASE WHEN partner2 IS NOT NULL THEN 1 ELSE 0 END +" \
                      "CASE WHEN partner3 IS NOT NULL THEN 1 ELSE 0 END) AS filled_count " \
                      f"FROM {matrix_type}_level_{matrix_level} WHERE user_id=$1;"
        else:
            if matrix_level in (1, 3):
                sql = "SELECT (CASE WHEN partner1 IS NOT NULL THEN 1 ELSE 0 END +" \
                      "CASE WHEN partner2 IS NOT NULL THEN 1 ELSE 0 END +" \
                      "CASE WHEN partner3 IS NOT NULL THEN 1 ELSE 0 END) AS filled_count " \
                      f"FROM {matrix_type}_level_{matrix_level} WHERE user_id=$1;"
            else:
                sql = "SELECT (CASE WHEN partner1 IS NOT NULL THEN 1 ELSE 0 END +" \
                      "CASE WHEN partner2 IS NOT NULL THEN 1 ELSE 0 END) AS filled_count " \
                      f"FROM {matrix_type}_level_{matrix_level} WHERE user_id=$1;"
        return await self.pool.fetchval(sql, user_id)

    async def get_users_count(self) -> int:
        return await self.pool.fetchval("SELECT COUNT(*) FROM users")