import asyncpg
import sqlite3
import asyncio
from datetime import datetime
from asyncpg.exceptions import UniqueViolationError
from asyncpg.pool import Pool
from typing import Union


class DataBase:
    def __init__(self):
        self.pool: Union[Pool, None] = None

    async def create_pool(self):
        self.pool = await asyncpg.create_pool(user='postgres', host='localhost', database='matrixbot_db',
                                              password='postgres')

    async def create_tables(self):
        sql = "CREATE TABLE IF NOT EXISTS users(id serial, user_id bigint unique, username text, demo_balance integer," \
              "withdraw_balance integer, cumulative_balance integer, demo_cumulative_balance integer," \
              "inviter bigint, balance_total_earned integer, balance_net_earned integer, join_date date, expclone_date timestamp," \
              "demo_level int, classic_level int, sotka_level int);" \
              "CREATE TABLE IF NOT EXISTS sotka_table(id serial, user_id bigint unique, level integer, purchase_date date);" \
              "CREATE TABLE IF NOT EXISTS referrals(id serial, user_id bigint, referral_id bigint unique);" \
              "CREATE TABLE IF NOT EXISTS clones(user_id bigint, clone_id serial, matrix_type text, matrix_level int," \
              "clone_serial_number int);" \
              "CREATE TABLE IF NOT EXISTS money_box(amount int);" \
              ""
        for i in range(1, 6):
            if i % 2 == 0:
                sql += f"CREATE TABLE IF NOT EXISTS classic_level_{i}(id serial, user_id bigint unique, partner1 bigint, partner2 bigint," \
                       f"partner3 bigint);"
                sql += f"CREATE TABLE IF NOT EXISTS demo_level_{i}(id serial, user_id bigint unique, partner1 bigint, partner2 bigint," \
                       f" partner3 bigint);"
            else:
                sql += f"CREATE TABLE IF NOT EXISTS classic_level_{i}(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);"
                sql += f"CREATE TABLE IF NOT EXISTS demo_level_{i}(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);"
            sql += "CREATE TABLE IF NOT EXISTS sotka_level_1(id serial, user_id bigint unique, partner1 bigint, partner2 bigint, partner3 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_2(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_3(id serial, user_id bigint unique, partner1 bigint, partner2 bigint, partner3 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_4(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_5(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_6(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_7(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_8(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_9(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);" \
                   "CREATE TABLE IF NOT EXISTS sotka_level_10(id serial, user_id bigint unique, partner1 bigint, partner2 bigint);"
        await self.pool.execute(sql)

    async def users(self):
        users = cursor.execute(f"SELECT * FROM Users").fetchall()

        for i in users:
            user_level = what_is_user_level(int(i[1]))
            date1 = datetime.strptime(str(i[13]), "%Y-%m-%d %H:%M:%S")
            date2 = datetime.strptime(str(i[12]), "%Y-%m-%d %H:%M")

            await self.pool.execute("""INSERT INTO users(sotka_level, user_id, demo_balance, withdraw_balance,
            cumulative_balance, demo_cumulative_balance, inviter, balance_total_earned, balance_net_earned, join_date,
            expclone_date, demo_level, classic_level, username)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)""",
                    0, int(i[1]), int(i[3]), int(i[4]), int(i[5]), int(i[9]), int(i[7]), int(i[10]), int(i[11]), date1,
                    date2, int(user_level['demo']), int(user_level['classic']), str(i[2]))

    async def referrals(self):
        referrals = cursor.execute(f"SELECT * FROM Referals").fetchall()

        for i in referrals:
            try:
                await self.pool.execute("INSERT INTO referrals(user_id, referral_id) VALUES($1, $2)",
                                        int(i[0]), int(i[1]))
            except Exception as err:
                print(err)

    async def matrix(self, matrix_type):
        for level in range(1, 6):
            users = cursor.execute(f"SELECT * FROM {matrix_type}_level_{level}").fetchall()
            
            used_clones = []
            for i in users:
                req_data = []
                for j in i:
                    user_split = j.split("_")
                    if user_split[-1] != "0" and j not in used_clones:
                        await self.pool.execute(f"""INSERT INTO clones(user_id, matrix_type, matrix_level, clone_serial_number)
                                                        VALUES($1, $2, $3, $4)""",
                                                        int(user_split[0]), matrix_type, level, int(user_split[-1]))
                        max_id1 = await self.pool.fetch("SELECT clone_id FROM clones ORDER BY clone_id DESC LIMIT 1")

                        req_data.append(int(max_id1[0][0]))
                        used_clones.append(j)
                    elif j in used_clones and user_split[-1] != "0":
                        clone_info = await self.pool.fetch("SELECT clone_id FROM clones WHERE user_id=$1 AND clone_serial_number=$2", int(user_split[0]), int(user_split[-1]))
                        req_data.append(int(clone_info[0][0]))
                    elif user_split[-1] == "0":
                        req_data.append(int(user_split[0]))
                try:
                    if level in [1, 3, 5]:
                        await self.pool.execute(f"INSERT INTO {matrix_type}_level_{level}(user_id, partner1, partner2) VALUES($1, $2, $3)",
                                                req_data[0], req_data[1], req_data[2])
                    elif level in [2, 4]:
                        await self.pool.execute(f"INSERT INTO {matrix_type}_level_{level}(user_id, partner1, partner2) VALUES($1, $2, $3)",
                                                req_data[0], req_data[1], req_data[2])
                except Exception as err:
                    print("---")

    async def sotka_activated_users(self):

        all_data = cursor.execute(f"SELECT * FROM ActivatedUsers").fetchall()
        
        users = {}
        for i in all_data:
            if int(i[1]) not in users:
                users[int(i[1])] = [int(i[2]), str(i[3])]
            elif int(i[1]) in users and users[int(i[1])][0] < int(i[2]):
                users[int(i[1])][0] = int(i[2])
        for key, value in users.items():
            date = datetime.strptime(value[1], "%Y-%m-%d %H:%M:%S")
            await self.pool.execute("INSERT INTO sotka_table(user_id, level, purchase_date) VALUES($1, $2, $3)",
                int(key), int(value[0]), date)

    async def drop_tables(self):
        tables = ["classic_level_1", "classic_level_2", "classic_level_3", "classic_level_4", "classic_level_5", 
                    "demo_level_1", "demo_level_2", "demo_level_3", "demo_level_4", "demo_level_5", "users", "referrals", "clones", "money_box",
                    "sotka_table", "sotka_level_1", "sotka_level_2", "sotka_level_3", "sotka_level_4", "sotka_level_5", "sotka_level_6", "sotka_level_7", 
                    "sotka_level_8", "sotka_level_9", "sotka_level_10", ]

        for table_name in tables:
            #result = await self.pool.fetch(f"SELECT 'drop table if exists "' || {table_name} || '" cascade;'"
            #                               " as pg_tbl_drop FROM pg_tables WHERE schemaname='public';")
            await self.pool.fetch(f"DROP TABLE IF EXISTS {table_name} cascade;")
            #print(result)



def what_is_user_level(user_id):
    #try:
        connect = sqlite3.connect("tgbase.db")
        cursor = connect.cursor()
        levels = {"demo": 0, "classic": 0}

        for i in range(1, 6):
            resultFind = cursor.execute(f"SELECT * FROM demo_level_{i} WHERE user_id LIKE '{user_id}%'").fetchall()
            if resultFind != []:
                levels['demo'] = i
        for i in range(1, 6):
            resultFind = cursor.execute(f"SELECT * FROM demo_level_{i} WHERE user_id LIKE '{user_id}%'").fetchall()
            if resultFind != []:
                levels['classic'] = i
        return levels
    #except Exception as err:
        print(err)


sqlite_base = sqlite3.connect('tgbase.db')
cursor = sqlite_base.cursor()
a = DataBase()

asyncio.get_event_loop().run_until_complete(a.create_pool())

asyncio.get_event_loop().run_until_complete(a.drop_tables())

asyncio.get_event_loop().run_until_complete(a.create_tables())
asyncio.get_event_loop().run_until_complete(a.sotka_activated_users())
asyncio.get_event_loop().run_until_complete(a.users())
asyncio.get_event_loop().run_until_complete(a.referrals())
asyncio.get_event_loop().run_until_complete(a.matrix("demo"))
asyncio.get_event_loop().run_until_complete(a.matrix("classic"))



