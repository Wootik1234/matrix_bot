bot_token = '6037412322:AAEZE8EaReEc3OqLcEgsqjFlQIZzpjdjGKs'  # bot token from @BotFather
admins = [5750214329, 1912825108]  # 5750214329 / 1912825108 first element of a list is a main admin
forward_ch = -1001900292378  # channel to resend place closed messages and payment logs
group_chat = -957482206  # chat to resend messages about payments to participants

# database access
db_host = 'localhost'
db_user = 'postgres'
db_pass = 'none'
db_name = 'matrixbot_db'

# path to images
main_menu_image = r'sources/main_menu.jpg'
about_image = r'sources/about.jpg'
account_image = r'sources/account.jpg'
referral_image = r'sources/referral.jpg'
cash_image = r'sources/cash.jpg'
demo_image = r'sources/demo_matrix.jpg'
matrix_image = r'sources/matrix.jpg'
first_level_demo_image = r'sources/1st_level_demo.jpg'
second_level_demo_image = r'sources/2nd_level_demo.jpg'
third_level_demo_image = r'sources/3rd_level_demo.jpg'
fourth_level_demo_image = r'sources/4th_level_demo.jpg'
fifth_level_demo_image = r'sources/5th_level_demo.jpg'
first_level_classic_image = r'sources/1st_level_classic.jpg'
second_level_classic_image = r'sources/2nd_level_classic.jpg'
third_level_classic_image = r'sources/3rd_level_classic.jpg'
fourth_level_classic_image = r'sources/4th_level_classic.jpg'
fifth_level_classic_image = r'sources/5th_level_classic.jpg'


# matrix config
demo_matrix_config = {
    1: 500,
    2: 1000,
    3: 2500,
    4: 4000,
    5: 10000
}

classic_matrix_config = {
    1: 500,
    2: 1000,
    3: 2500,
    4: 4000,
    5: 10000
}

sotka_martix_config = {
    1: 100,
    2: 300,
    3: 600,
    4: 1500,
    5: 2500,
    6: 4000,
    7: 6000,
    8: 10000,
    9: 15000,
    10: 20000
}

# rewards for closing demo matrix by levels
demo_rewards = {
    1: {'partner1': ['cum_500'],
        'partner2': ['cum_500']},
    2: {'partner1': ['cum_1000'],
        'partner2': ['cum_500', 'clone_set'],
        'partner3': ['cum_1000']},
    3: {'partner1': ['cum_1500', 'draw_1000'],
        'partner2': ['cum_2500']},
    4: {'partner1': ['cum_3500', 'clone_set'],
        'partner2': ['cum_2500', 'inv_1500'],
        'partner3': ['cum_4000']},
    5: {'partner1': ['draw_7000', 'inv_2500', 'clone_set'],
        'partner2': ['draw_7000', 'adm_3000']}
}

# rewards for closed places

classic_rewards = {
    1: {'partner1': ['cum_500'],
        'partner2': ['cum_500']},
    2: {'partner1': ['cum_1000'],
        'partner2': ['cum_500', 'clone_set'],
        'partner3': ['cum_1000']},
    3: {'partner1': ['cum_1500', 'draw_1000'],
        'partner2': ['cum_2500']},
    4: {'partner1': ['cum_3500', 'clone_set'],
        'partner2': ['cum_2500', 'inv_1500'],
        'partner3': ['cum_4000']},
    5: {'partner1': ['draw_7000', 'inv_2500', 'clone_set'],
        'partner2': ['draw_7000', 'adm_3000']}
}

sotka_rewards = {
    1: {'partner1': ['cum_100'],
        'partner2': ['cum_100'],
        'partner3': ['cum_100']},
    2: {'partner1': ['cum_300'],
        'partner2': ['cum_300']},
    3: {'partner1': ['draw_100', 'cum_500'],
        'partner2': ['cum_500', 'clone_set'],
        'partner3': ['inv_100', 'cum_500']},
    4: {'partner1': ['draw_200', 'cum_1300'],
        'partner2': ['cum_1200', 'inv_100', 'clone_set', 'box_100']},
    5: {'partner1': ['draw_500', 'cum_2000'],
        'partner2': ['cum_2000', 'inv_200', 'clone_set', 'clone_set', 'box_100']},
    6: {'partner1': ['draw_1000', 'cum_3000'],
        'partner2': ['cum_3000', 'inv_400', 'box_100', 'clone_set_j']},
    7: {'partner1': ['draw_1000', 'cum_5000'],
        'partner2': ['cum_5000', 'inv_400', 'box_100', 'clone_set', 'clone_set',
                     'clone_set', 'clone_set', 'clone_set']},
    8: {'partner1': ['draw_2000', 'cum_7500', ' clone_set_j'],
        'partner2': ['cum_7500', 'inv_1000', 'box_300', 'clone_set', 'clone_set',
                     'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set_j']},
    9: {'partner1': ['draw_4000', 'cum_10000', 'clone_set', 'clone_set', 'clone_set', 'clone_set',
                     'clone_set', 'clone_set_j'],
        'partner2': ['draw_2000', 'cum_10000', 'inv_1500', 'box_300', 'clone_set', 'clone_set',
                     'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set_j']},
    10: {'partner1': ['draw_16000', 'inv_2000', 'box_300', 'clone_set', 'clone_set', 'clone_set', 'clone_set',
                      'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set',
                      'clone_set', 'clone_set_j'],
         'partner2': ['draw_16000', 'inv_2000', 'box_200', 'clone_set', 'clone_set', 'clone_set',
                      'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set', 'clone_set',
                      'clone_set', 'clone_set', 'clone_set', 'clone_set_j', 'end']}}
