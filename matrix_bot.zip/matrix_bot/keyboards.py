from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from config import admins


class KeyBoards:
    @staticmethod
    def start_kb(user_id: int):
        buttons = [InlineKeyboardButton(text='💠 Матрицы', callback_data='matrix'),
                   InlineKeyboardButton(text='🔐 Личный кабинет', callback_data='account'),
                   InlineKeyboardButton(text='🎯Конструктор визиток', callback_data='card_design'),
                   InlineKeyboardButton(text='🎁 Конкурсы', callback_data='contests'),
                   InlineKeyboardButton(text='📚 О проекте', callback_data='about')]
        kb = InlineKeyboardMarkup(row_width=2)
        for b in buttons:
            kb.add(b)
        kb.add(InlineKeyboardButton(text='💬 Чат проекта', url='https://t.me/prostobotlegkoiprosto'),
               InlineKeyboardButton(text='⚡️ Официальный канал', url='https://t.me/prostobotlegko'))
        if user_id in admins:
            kb.add(InlineKeyboardButton(text='Админ-панель', callback_data='admin_panel'))
        return kb

    @staticmethod
    def about_kb():
        kb = InlineKeyboardMarkup(row_width=2)
        kb.add(InlineKeyboardButton(text='📊 Маркетинг', url='https://telegra.ph/Marketing-proekta-Prostobot-02-20'),
               InlineKeyboardButton(text='🧲 Промо-материалы', url='https://telegra.ph/Promo-materialy-Prostobot-02-20'),
               InlineKeyboardButton(text='📖 База знаний', url='https://telegra.ph/Baza-znanij-Prostobot-02-20'),
               InlineKeyboardButton(text='💬 Чат проекта', url='https://t.me/prostobotlegkoiprosto'),
               InlineKeyboardButton(text='⚡️ Официальный канал', url='https://t.me/prostobotlegko'))
        kb.add(InlineKeyboardButton(text='🔙Назад', callback_data='main_menu'))
        return kb

    @staticmethod
    def card_designer_kb():
        kb = InlineKeyboardMarkup(row_width=1)
        kb.add(InlineKeyboardButton(text="🏆 Живая матрица", callback_data="classic_matrix"),
               InlineKeyboardButton(text="🗯 Информация о HUB projects", url='https://telegra.ph/Opisanie-konstruktora-HUB-projects-03-12'),
               InlineKeyboardButton(text='🔙Назад', callback_data='main_menu'))
        return kb

    @staticmethod
    def sotka_kb(sotka_level: int):
        kb = InlineKeyboardMarkup(row_width=2)
        buttons = []
        emojis = ['❌', '✅']
        for i in range(1, 11):
            if i <= sotka_level:
                buttons.append(InlineKeyboardButton(text=f'{emojis[1]}{i} Уровень', callback_data=f'sotka_level_{i}'))
            else:
                buttons.append(InlineKeyboardButton(text=f'{emojis[0]}{i} Уровень', callback_data=f'sotka_level_{i}'))
        buttons.append(InlineKeyboardButton(text='🔙Назад', callback_data='back_to_matrix'))
        kb.add(*buttons)
        return kb

    @staticmethod
    def acc_kb():
        kb = InlineKeyboardMarkup(row_width=1)
        kb.add(InlineKeyboardButton(text='⚡️ Реферальная программа', callback_data='ref_program'),
               InlineKeyboardButton(text='💰 Кошелек', callback_data='account_cash'),
               InlineKeyboardButton(text='🔙Назад', callback_data='main_menu'))
        return kb

    @staticmethod
    def cash_kb():
        kb = InlineKeyboardMarkup(row_width=2)
        kb.add(InlineKeyboardButton(text='📥 Пополнить', callback_data='top_up_balance'),
               InlineKeyboardButton(text='📤 Вывод', callback_data='withdraw_balance'),
               InlineKeyboardButton(text='💸 Перевод участнику', callback_data='withdraw_to_participant'))
        kb.add(InlineKeyboardButton(text='🔙Назад', callback_data='back_to_acc'))
        return kb

    @staticmethod
    def matrix_kb():
        kb = InlineKeyboardMarkup(row_width=1)
        kb.add(InlineKeyboardButton(text='⚡️ПростоСотка', callback_data='sotka_activation'),
               InlineKeyboardButton("🎗 Демо матрица", callback_data="demo_matrix"),
               InlineKeyboardButton("🏆 Живая матрица", callback_data="classic_matrix"),
               InlineKeyboardButton(text='🔙Назад', callback_data='main_menu'))
        return kb

    @staticmethod
    def matrix_levels_kb(matrix_type: str):
        if matrix_type == 'demo':
            emoji = '🔹'
        else:
            emoji = '🔸'
        kb = InlineKeyboardMarkup(row_width=2)
        buttons = []
        for i in range(1, 6):
            buttons.append(InlineKeyboardButton(text=f"{emoji} {i} Уровень", callback_data=f'{matrix_type}_level_{i}'))
        buttons.append(InlineKeyboardButton(text='🔙Назад', callback_data='back_to_matrix'))
        kb.add(*buttons)
        return kb

    @staticmethod
    def buy_kb(allow_buy: bool):
        kb = InlineKeyboardMarkup(row_width=2)
        if allow_buy:
            kb.add(InlineKeyboardButton(text='💎 Купить', callback_data='buy_level'),
                   InlineKeyboardButton(text='🔙Назад', callback_data='back_to_matrix'))
        else:
            kb.add(InlineKeyboardButton(text='🔙Назад', callback_data='back_to_matrix'))
        return kb

    @staticmethod
    def buy_sotka_kb(allow_buy: bool):
        kb = InlineKeyboardMarkup(row_width=2)
        if allow_buy:
            kb.add(InlineKeyboardButton(text='💎 Купить', callback_data='buy_level'),
                   InlineKeyboardButton(text='🔙Назад', callback_data='back_to_sotka'))
        else:
            kb.add(InlineKeyboardButton(text='🔙Назад', callback_data='back_to_sotka'))
        return kb

    @staticmethod
    def buy_classic_kb(allow_buy: bool):
        kb = InlineKeyboardMarkup(row_width=2)
        if allow_buy:
            kb.add(InlineKeyboardButton(text='💎 Купить', callback_data='buy_level_classic'),
                   InlineKeyboardButton(text='🔙Назад', callback_data='back_to_matrix'))
        else:
            kb.add(InlineKeyboardButton(text='🔙Назад', callback_data='back_to_matrix'))
        return kb

    @staticmethod
    def buy_clone_kb(price, matrix_type, matrix_level, buy_allowed):
        kb = InlineKeyboardMarkup(row_width=2)
        if matrix_type == 'demo':
            currency = 'кредитов'
        else:
            currency = 'RUB'
        if buy_allowed and matrix_level == 1:
            kb.add(InlineKeyboardButton(text=f'🔋 Купить клона за {price} {currency}', callback_data=f'buy_clone_{matrix_type}_{matrix_level}_{price}'))
            kb.add(InlineKeyboardButton(text='🎑 Показать стол картинкой', callback_data='show_board'))
            kb.add(InlineKeyboardButton(text='👥 Выбрать клона', callback_data=f'choose_clone_{matrix_type}_{matrix_level}'),
                   InlineKeyboardButton(text='🔙Назад', callback_data='back_to_matrix'))
        else:
            kb.add(InlineKeyboardButton(text='🎑 Показать стол картинкой', callback_data='show_board'))
            kb.add(InlineKeyboardButton(text='👥 Выбрать клона', callback_data=f'choose_clone_{matrix_type}_{matrix_level}'),
                   InlineKeyboardButton(text='🔙Назад', callback_data='back_to_matrix'))
        return kb

    @staticmethod
    def buy_sotka_clone_kb(price, matrix_type, matrix_level, buy_allowed):
        kb = InlineKeyboardMarkup(row_width=2)
        if matrix_type == 'demo':
            currency = 'кредитов'
        else:
            currency = 'RUB'
        if buy_allowed:
            kb.add(InlineKeyboardButton(text=f'🔋 Купить клона за {price} {currency}', callback_data=f'buy_clone_{matrix_type}_{matrix_level}_{price}'))
            kb.add(InlineKeyboardButton(text='🎑 Показать стол картинкой', callback_data='show_board'))
            kb.add(InlineKeyboardButton(text='👥 Выбрать клона', callback_data=f'choose_clone_{matrix_type}_{matrix_level}'),
                   InlineKeyboardButton(text='🔙Назад', callback_data='back_to_sotka'))
        else:
            kb.add(InlineKeyboardButton(text='🎑 Показать стол картинкой', callback_data='show_board'))
            kb.add(InlineKeyboardButton(text='👥 Выбрать клона', callback_data=f'choose_clone_{matrix_type}_{matrix_level}'),
                   InlineKeyboardButton(text='🔙Назад', callback_data='back_to_sotka'))
        return kb

    @staticmethod
    def confirm_buy_kb():
        kb = InlineKeyboardMarkup(row_width=2)
        kb.add(InlineKeyboardButton(text='Купить', callback_data='confirm_buy'),
               InlineKeyboardButton(text='Отмена', callback_data='back_to_matrix'))
        return kb

    @staticmethod
    def confirm_sotka_buy_kb():
        kb = InlineKeyboardMarkup(row_width=2)
        kb.add(InlineKeyboardButton(text='Купить', callback_data='confirm_buy'),
               InlineKeyboardButton(text='Отмена', callback_data='back_to_sotka'))
        return kb

    @staticmethod
    def referral_kb():
        kb = InlineKeyboardMarkup(row_width=1)
        kb.add(InlineKeyboardButton(text='📬 Рассылка по первой линии рефералов', callback_data='referral_mailing'),
               InlineKeyboardButton(text='📇 Скачать базу рефералов', callback_data='download_ref_base'),
               InlineKeyboardButton(text='🔙Назад', callback_data='back_to_acc'))
        return kb

    @staticmethod
    def cancel_kb():
        return InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton(text='🔙Назад', callback_data='back_to_acc'))

    @staticmethod
    def clones_kb(clones: list):
        kb = InlineKeyboardMarkup(row_width=2)
        kb.add(InlineKeyboardButton(text='<', callback_data='prev_page'),
               InlineKeyboardButton(text='>', callback_data='next_page'))
        buttons = []
        clone_counter = 1
        for c in clones:
            buttons.append(InlineKeyboardButton(text=f'{clone_counter}', callback_data=f'clone_{c["clone_id"]}'))
            clone_counter += 1
        kb.add(*buttons)
        kb.add(InlineKeyboardButton(text='🔙Назад', callback_data='back_to_levels'))
        return kb

    @staticmethod
    def admin_kb():
        kb = InlineKeyboardMarkup(row_width=2)
        kb.add(InlineKeyboardButton(text='Выгрузить список пользователей в csv файл', callback_data='users_to_csv'),
               InlineKeyboardButton(text='Выгрузить структуру в csv файл', callback_data='structure_to_csv'),
               InlineKeyboardButton(text='Рассылка', callback_data='admin_mailing'),
               InlineKeyboardButton(text='Назад', callback_data='main_menu'))
        return kb

    @staticmethod
    def confirm_mail_kb():
        kb = InlineKeyboardMarkup(row_width=1)
        kb.add(InlineKeyboardButton(text='Да', callback_data='confirm_mailing'),
               InlineKeyboardButton(text='Нет', callback_data='reject_mailing'))
        return kb