import os
from PIL import Image, ImageFont, ImageDraw
from uuid import uuid4


class ImageWorker:
    def __init__(self, matrix_level: int, matrix_type: str, data: list, closed_places: int):
        self.font_al = r'sources/templates/fonts/a_AlternaNr.ttf'
        self.font_gil = r'sources/templates/fonts/gilroy-regular.ttg'
        self.matrix_types = {'demo': 'Демо', 'classic': 'Живая', 'sotka': 'ПростоСотка'}
        self.matrix_level = matrix_level
        self.matrix_type = matrix_type
        self.closed_places = closed_places
        self.data = data
        self.double_coords_1 = [{"photo": (584, 59), "text": (610, 175)},
            {"photo": (426, 267), "text": (451, 385)},
            {"photo": (755, 267), "text": (781, 385)}]
        self.double_coords_2 = [{"photo": (343, 502), "text": (370, 625)},
            {"photo": (491, 502), "text": (519, 625)},
            {"photo": (675, 502), "text": (702, 625)},
            {"photo": (822, 502), "text": (850, 625)}]
        self.triple_coords_1 = [
            {"photo": (588, 70), "text": (610, 175)},
            {"photo": (191, 336), "text": (212, 438)},
            {"photo": (590, 333), "text": (611, 438)},
            {"photo": (989, 333), "text": (1009, 438)}]
        self.triple_coords_2 = [{"photo": (61, 541), "text": (84, 646)},
                                {"photo": (188, 541), "text": (210, 646)},
                                {"photo": (316, 541), "text": (339, 646)},
                                {"photo": (461, 538), "text": (482, 646)},
                                {"photo": (589, 538), "text": (610, 646)},
                                {"photo": (716, 538), "text": (738, 646)},
                                {"photo": (859, 538), "text": (881, 646)},
                                {"photo": (987, 538), "text": (1009, 646)},
                                {"photo": (1115, 538), "text": (1137, 646)}]
        # self.triple_coords_2 = [{"photo": (461, 538), "text": (482, 646)},
        #                         {"photo": (589, 538), "text": (610, 646)},
        #                         {"photo": (716, 538), "text": (738, 646)},
        #                         {"photo": (61, 541), "text": (84, 646)},
        #                         {"photo": (188, 541), "text": (210, 646)},
        #                         {"photo": (316, 541), "text": (339, 646)},
        #                         {"photo": (989, 333), "text": (1009, 438)},
        #                         {"photo": (859, 538), "text": (881, 646)},
        #                         {"photo": (987, 538), "text": (1009, 646)},
        #                         {"photo": (1115, 538), "text": (1137, 646)}
        #                         ]

    def create_image(self):
        if self.matrix_type in ('demo', 'classic'):
            if self.matrix_level % 2 != 0:
                places = 2
                background_path = 'sources/templates/matrix_double.jpg'
            else:
                places = 3
                background_path = 'sources/templates/matrix_triple.jpg'
        else:
            if self.matrix_level in (1, 3):
                places = 3
                background_path = 'sources/templates/sotka_triple.jpg'
            else:
                places = 2
                background_path = 'sources/templates/sotka_double.jpg'
        background = Image.open(background_path)
        image_text = f'Уровень {self.matrix_level}\n\n{self.matrix_types.get(self.matrix_type)} матрица\n' \
                     f'Закрытых мест подо мной: {self.closed_places} из {places}'
        font = ImageFont.truetype(self.font_al, 42)
        drawer = ImageDraw.Draw(background)
        drawer.text((10, 10), text=image_text, font=font, fill='white')
        save_path = 'sources/temp_images/' + str(uuid4()) + '.jpg'
        background.save(save_path)
        return save_path

    def set_positions(self, image_path, next_partners):
        if self.matrix_type in ('demo', 'classic'):
            if self.matrix_level % 2 != 0:
                coords = self.double_coords_1
                second_coords = self.double_coords_2
                mask_path = 'sources/templates/mask2.png'
            else:
                coords = self.triple_coords_1
                second_coords = self.triple_coords_2
                mask_path = 'sources/templates/mask3.png'
        else:
            if self.matrix_level not in (1, 3):
                coords = self.double_coords_1
                second_coords = self.double_coords_2
                mask_path = 'sources/templates/mask2.png'
            else:
                coords = self.triple_coords_1
                second_coords = self.triple_coords_2
                mask_path = 'sources/templates/mask3.png'
        if not next_partners:
            coords.append(second_coords[0])
        mask = Image.open(mask_path).convert('L')
        image = Image.open(image_path)
        drawer = ImageDraw.Draw(image)
        font = ImageFont.truetype(self.font_al, 13)
        for i, k in zip(self.data, coords):
            if i is None:
                continue
            if i[2]:
                user_avatar = Image.open(i[2]).resize(mask.size)
            else:
                user_avatar = Image.open('sources/templates/default_avatar.jpg').resize(mask.size)
            image.paste(user_avatar, k['photo'], mask)
            if i[3]:
                drawer.text(k['text'], f"@{i[0]}\n{i[1]} Клон {i[4]}", font=font)
            else:
                drawer.text(k['text'], f"@{i[0]}\n{i[1]}", font=font)
        if next_partners:
            for i, k in zip(next_partners, second_coords):
                if i is None:
                    continue
                if i[2]:
                    user_avatar = Image.open(i[2]).resize(mask.size)
                else:
                    user_avatar = Image.open('sources/templates/default_avatar.jpg').resize(mask.size)
                image.paste(user_avatar, k['photo'], mask)
                if i[3]:
                    drawer.text(k['text'], f"@{i[0]}\n{i[1]} Клон {i[4]}", font=font)
                else:
                    drawer.text(k['text'], f"@{i[0]}\n{i[1]}", font=font)
        image.save(image_path)


class PaymentImage:
    def __init__(self, avatar_path: str, user_name: str, matrix_type: str, payment: int, total_earned: int):
        self.matrix = matrix_type
        self.payment = payment
        self.total_earned = total_earned
        self.background = 'sources/templates/payment.jpg'
        self.mask = 'sources/templates/payment_mask.png'
        self.font_al = r'sources/templates/fonts/a_AlternaNr.ttf'
        self.avatar_pos, self.nickname_pos = (825, 47), (800, 520)
        self.matrix_pos = (255, 150)
        self.payment_pos, self.total_payment_pos = (290, 338), (268, 538)
        self.username = user_name
        if avatar_path:
            self.avatar_path = avatar_path
        else:
            self.avatar_path = 'sources/templates/1.jpg'

    def create_image(self):
        matrix_types = {'classic': 'Живая матрица', 'demo': 'ДЕМО матрица', 'sotka': 'Простосотка'}
        background = Image.open(self.background)
        mask = Image.open(self.mask).convert('L')
        matrix = matrix_types.get(self.matrix)
        user_avatar = Image.open(self.avatar_path).resize(mask.size)
        drawer = ImageDraw.Draw(background)
        font = ImageFont.truetype(self.font_al, 75)
        background.paste(user_avatar, self.avatar_pos, mask)
        text_size = drawer.textsize(text=self.username, font=font)
        x = self.nickname_pos[0] + (user_avatar.size[0] - text_size[0]) / 2
        y = self.nickname_pos[1]
        text_color = '#b44574'
        drawer.text((x, y), self.username, font=font, fill=text_color)
        drawer.text(self.payment_pos, f'{self.payment} RUB', font=font, fill=text_color)
        drawer.text(self.matrix_pos, matrix, font=font, fill=text_color)
        drawer.text(self.total_payment_pos, f'{self.total_earned} RUB', font=font, fill=text_color)
        image_path = f'sources/temp_images/{uuid4()}.jpg'
        background.save(image_path)
        return image_path


def remove_file(file_path):
    try:
        os.remove(file_path)
    except Exception as e:
        print(e)



