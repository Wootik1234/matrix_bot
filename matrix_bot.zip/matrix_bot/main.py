import logging
import asyncio
import messages
import config
import states
from uuid import uuid4
from utils import ImageWorker, remove_file, PaymentImage
from datetime import datetime
from keyboards import KeyBoards
from database import DataBase
from aiogram import Bot, Dispatcher, types
from aiogram.utils.exceptions import ChatNotFound, BotBlocked, BadRequest, MessageNotModified
from aiogram.dispatcher import FSMContext, filters
from aiogram.contrib.fsm_storage.memory import MemoryStorage

bot = Bot(token=config.bot_token)
logging.basicConfig(level=logging.DEBUG)
dp = Dispatcher(bot, storage=MemoryStorage())
kb = KeyBoards()
db = DataBase()
user_states = states.UserStates()


@dp.message_handler(commands='test', state='*')
async def test(message: types.Message):
    await db.pool.execute("update users set expclone_date=date(now());")


@dp.message_handler(commands='start', state='*')
async def start(message: types.Message, state: FSMContext):
    await state.finish()
    if not await db.is_user_exists(message.from_user.id):
        if message.from_user.username:
            username = message.from_user.username
        else:
            username = None
        if " " in message.text:
            referrer = message.text.split()[1]
            try:
                referrer = int(referrer)
            except ValueError:
                pass
            if await db.is_user_exists(referrer):
                await db.add_user(message.from_user.id, username, referrer)
                await db.add_referral(referrer, message.from_user.id)
                await bot.send_message(referrer, messages.new_referral_message.format(username))
            else:
                await db.add_user(message.from_user.id, username, config.admins[0])
                await db.add_referral(config.admins[0], message.from_user.id)
        else:
            await db.add_user(message.from_user.id, username, config.admins[0])
            if message.from_user.id != config.admins[0]:
                await db.add_referral(config.admins[0], message.from_user.id)
    await db.add_admin_to_matrix(config.admins[0])

    with open(config.main_menu_image, 'rb') as file:
        await bot.send_photo(message.from_user.id, file, caption=messages.start_message,
                             reply_markup=kb.start_kb(message.from_user.id))


@dp.callback_query_handler(text='about')
async def about(callback: types.CallbackQuery):
    with open(config.about_image, 'rb') as file:
        await callback.message.edit_media(types.input_media.InputMediaPhoto(file), reply_markup=kb.about_kb())


@dp.callback_query_handler(text='card_design')
async def card_designer(callback: types.CallbackQuery):
    await callback.message.edit_caption(messages.card_designer_message, reply_markup=kb.card_designer_kb())


@dp.callback_query_handler(text='account')
async def account(callback: types.CallbackQuery):
    message = messages.account_message
    inviter = await db.get_referrer(callback.from_user.id)
    demo_level = await db.get_demo_level(callback.from_user.id)
    classic_level = (await db.get_classic_level(callback.from_user.id))['classic_level']
    demo_places = await db.get_demo_matrix_places(callback.from_user.id)
    classic_places = await db.get_classic_matrix_places(callback.from_user.id)
    message = message.format(callback.from_user.id, (await bot.get_chat(inviter)).username,
                             demo_level, demo_places, classic_level, classic_places)
    with open(config.account_image, 'rb') as file:
        await callback.message.edit_media(types.input_media.InputMediaPhoto(file))
    await callback.message.edit_caption(message, reply_markup=kb.acc_kb())


@dp.callback_query_handler(text='ref_program')
async def ref_program(callback: types.CallbackQuery):
    with open(config.referral_image, 'rb') as file:
        await callback.message.edit_media(types.input_media.InputMediaPhoto(file))
    inviter = await db.get_referrer(callback.from_user.id)
    inviter = (await bot.get_chat(inviter)).username
    ref_count = await db.get_ref_count(callback.from_user.id)
    referrals = (await db.get_all_referrals(callback.from_user.id))
    all_referrals = []
    for r in referrals:
        all_referrals.append(r['referral_id'])
    if all_referrals:
        demo_activated_referrals = await db.get_demo_activated_referrals(all_referrals)
        classic_activated_referrals = await db.get_classic_activated_referrals(all_referrals)
    else:
        demo_activated_referrals, classic_activated_referrals = 0, 0
    await callback.message.edit_caption(messages.ref_message.format(
        inviter, callback.from_user.id, ref_count, 0, 0, 0, 0, ref_count, demo_activated_referrals,
        classic_activated_referrals, 0), reply_markup=kb.referral_kb())


@dp.callback_query_handler(text='account_cash')
async def cash(callback: types.CallbackQuery):
    user = await db.get_user(callback.from_user.id)
    with open(config.cash_image, 'rb') as file:
        await callback.message.edit_media(types.input_media.InputMediaPhoto(file))
    await callback.message.edit_caption(messages.cash_message.format(user['demo_balance'], user['demo_cumulative_balance'],
                                                                     user['withdraw_balance'], user['cumulative_balance'],
                                                                     user['balance_total_earned'], user['balance_net_earned']),
                                        reply_markup=kb.cash_kb())


@dp.callback_query_handler(text=['main_menu', 'back_to_acc', 'back_to_matrix', 'cancel_buy',
                                 'back_to_sotka'],
                           state='*')
async def main_menu(callback: types.CallbackQuery, state: FSMContext):
    if callback.data == 'main_menu':
        with open(config.main_menu_image, 'rb') as file:
            message = await callback.message.edit_media(types.input_media.InputMediaPhoto(file),
                                                        reply_markup=kb.start_kb(callback.from_user.id))
            await message.edit_caption(caption=messages.start_message, reply_markup=kb.start_kb(callback.from_user.id))
    elif callback.data == 'back_to_acc':
        await state.finish()
        try:
            await account(callback)
        except BadRequest:
            with open(config.account_image, 'rb') as file:
                await bot.send_photo(callback.from_user.id, file, reply_markup=kb.acc_kb())
    elif callback.data == 'back_to_matrix':
        await state.finish()
        await matrix_menu(callback)
    elif callback.data == 'cancel_buy':
        await state.finish()
    elif callback.data == 'back_to_sotka':
        await state.finish()
        await activation_sotka(callback)


@dp.callback_query_handler(text='sotka_activation')
async def activation_sotka(callback: types.CallbackQuery):
    sotka_level = await db.get_sotka_level(callback.from_user.id)
    try:
        await callback.message.edit_caption(messages.activation_message, reply_markup=kb.sotka_kb(sotka_level))
    except MessageNotModified:
        await callback.message.edit_text(messages.activation_message, reply_markup=kb.sotka_kb(sotka_level))

@dp.callback_query_handler(lambda c: c.data.startswith('sotka'))
async def sotka_matrix_levels(callback: types.CallbackQuery, state: FSMContext):
    data = callback.data.split('_')
    matrix_level = int(data[2])
    user_level = await db.get_sotka_level(callback.from_user.id)
    image_path = f"sources/sotka_level_{matrix_level}.jpg"
    level_price = config.sotka_martix_config.get(matrix_level)
    with open(image_path, 'rb') as file:
        await callback.message.edit_media(types.InputMediaPhoto(file))
    if matrix_level in (1, 3):
        if matrix_level <= user_level:
            await callback.message.edit_caption(messages.tripple_level_sotka.format(matrix_level, level_price),
                                                reply_markup=kb.buy_sotka_clone_kb(level_price, 'sotka',
                                                                                   matrix_level, True))
        elif matrix_level - 1 == user_level:
            await callback.message.edit_caption(messages.tripple_level_sotka.format(matrix_level, level_price),
                                                reply_markup=kb.buy_sotka_kb(True))
        else:
            await callback.message.edit_caption(messages.tripple_level_sotka.format(matrix_level, level_price),
                                                reply_markup=kb.buy_sotka_kb(False))
    else:
        if matrix_level <= user_level:
            await callback.message.edit_caption(messages.double_level_sotka.format(matrix_level, level_price),
                                                reply_markup=kb.buy_sotka_clone_kb(level_price, 'sotka',
                                                                                   matrix_level, True))
        elif matrix_level - 1 == user_level:
            await callback.message.edit_caption(messages.tripple_level_sotka.format(matrix_level, level_price),
                                                reply_markup=kb.buy_sotka_kb(True))
        else:
            await callback.message.edit_caption(messages.tripple_level_sotka.format(matrix_level, level_price),
                                                reply_markup=kb.buy_sotka_kb(False))
    async with state.proxy() as data:
        data['level_buy'] = matrix_level
        data['price'] = level_price
        data['matrix_type'] = 'sotka'
    await user_states.wait_for_buy_sotka.set()


@dp.callback_query_handler(lambda c: c.data.startswith('buy_clone'), state=user_states.wait_for_buy_sotka)
async def sotka_matrix_levels(callback: types.CallbackQuery, state: FSMContext):
    callback_data = callback.data.split('_')
    async with state.proxy() as data:
        data['matrix_type'] = callback_data[2]
        data['matrix_level'] = int(callback_data[3])
        data['price'] = int(callback_data[4])
    user_balance = await db.get_user_balance(callback.from_user.id, callback_data[2])
    if int(callback_data[4]) > user_balance:
        await callback.message.edit_caption(messages.not_enough_cash_message,
                                            reply_markup=kb.start_kb(callback.from_user.id))
        await state.finish()
    else:
        await callback.message.edit_caption(messages.clone_confirm_buy_message.format(
            callback_data[4], callback_data[3], 'Простосотка'), reply_markup=kb.confirm_sotka_buy_kb())
        await user_states.confirm_sotka_clone_buy.set()


@dp.callback_query_handler(text='buy_level', state=user_states.wait_for_buy_sotka)
async def sotka_matrix_levels(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_balance = await db.get_user_balance(callback.from_user.id, 'classic')
    if user_balance < data['price']:
        await callback.message.edit_caption(messages.not_enough_cash_message,
                                            reply_markup=kb.start_kb(callback.from_user.id))
        await state.finish()
    else:
        await callback.message.edit_caption(messages.confrim_buy_sotka_message.format(data['price'], data['level_buy']),
                                            reply_markup=kb.confirm_sotka_buy_kb())
        await user_states.confirm_sotka_buy.set()


@dp.callback_query_handler(state=user_states.confirm_sotka_clone_buy)
async def sotka_clone(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.edit_reply_markup(reply_markup=None)
    data = await state.get_data()
    level = data['level_buy']
    clone_id = await db.add_clone(callback.from_user.id, data['matrix_type'], level)
    inviter = await db.get_referrer(callback.from_user.id)
    empty_place = await db.get_empty_place_from_sotka(level, callback.from_user.id, callback.from_user.id)
    if empty_place < 100000:
        empty_place_id = await db.get_user_by_clone(empty_place)
    else:
        empty_place_id = empty_place
    await db.add_user_to_sotka_matrix(level, empty_place, clone_id)
    await db.decrease_withdraw_balance(empty_place_id, data['price'])
    await db.update_sotka_level(empty_place, level)
    partner_dict = config.sotka_rewards.get(level)
    partner = await db.get_last_filled_column_sotka(empty_place, level)
    rewards = partner_dict.get(partner)
    for r in rewards:
        try:
            temp_rewards = r.split('_')
            if temp_rewards[0] == 'cum':
                await db.increase_classic_cum_balance(empty_place_id, int(temp_rewards[1]))
            elif temp_rewards[0] == 'draw':
                await db.increase_classic_balance(empty_place_id, int(temp_rewards[1]))
                message = messages.sotka_place_closed_draw.format(level, temp_rewards[1])
                await send_payment_message(empty_place_id, 'sotka', temp_rewards[1], message)
            elif temp_rewards[0] == 'inv':
                inviter = await db.get_referrer(empty_place_id)
                await db.increase_classic_balance(inviter, int(temp_rewards[1]))
                message = messages.sotka_place_closed_draw.format(level, temp_rewards[1])
                await send_payment_message(inviter, 'sotka', temp_rewards[1], message)
            elif temp_rewards[0] == 'clone' and len(temp_rewards) == 2:
                clone_id = await db.add_clone(user_id=empty_place_id, matrix_type='sotka', matrix_level=1)
                empty_place_c = await db.get_empty_place_from_sotka(1, empty_place_id, callback.from_user.id)
                await db.add_user_to_sotka_matrix(1, empty_place_c, clone_id)
                await bot.send_message(empty_place_id, messages.sotka_place_closed_clone.format(level))
                await closed_place_check(empty_place_c, 'sotka', 1, callback)
            elif temp_rewards[0] == 'box':
                await db.add_money_to_box(int(temp_rewards[1]))
                await bot.send_message(empty_place_id, messages.sotka_place_closed_box.format(level, int(temp_rewards[1])))
            elif temp_rewards[0] == 'end':
                referrals = await db.get_active_referrals(empty_place_id)
                if len(referrals) >= 3:
                    money = await db.get_money_from_box()
                    money = money * 0.7
                    await db.remove_money_from_box(money)
                    money_per_user = money // len(referrals)
                    message = messages.sotka_box_destroy.format(money_per_user)
                    for i in referrals:
                        await db.increase_classic_balance(i['user_id'], money_per_user)
                        await send_payment_message(i['user_id'], 'sotka', money_per_user, message)
                        await asyncio.sleep(1)
            elif temp_rewards[2] == 'j':
                clone_id = await db.add_clone(user_id=empty_place_id, matrix_type='classic', matrix_level=1)
                await db.update_matrix_level(empty_place, 1, 'classic')
                empty_place_j = await db.get_empty_place(1, 'classic')
                if empty_place_j < 100000:
                    empty_place_id_j = await db.get_user_by_clone(empty_place_j)
                else:
                    empty_place_id_j = empty_place_j
                await db.add_user_to_classic_matrix(1, empty_place_j, clone_id)
                await bot.send_message(empty_place_id, messages.sotka_place_closed_clone_j.format(level))
                await closed_place_check(empty_place_j, 'classic', 1, callback)
        except IndexError:
            pass
    await bot.send_message(config.forward_ch, messages.clone_log_message('sotka', level, callback.from_user.id,
                                                                         callback.from_user.username, True))
    await asyncio.sleep(1)

    place_name = await bot.get_chat(empty_place_id)
    clone_number = await db.get_clone_number(empty_place)
    await bot.send_message(config.forward_ch, messages.clone_set_message('sotka', level, callback.from_user.id,
                                                                         callback.from_user.username, empty_place_id,
                                                                         place_name.username, clone_number))
    matrix_complete = await db.is_sotka_matrix_complete(empty_place_id, level)
    if matrix_complete and level != 10:
        await bot.send_message(empty_place_id, messages.sotka_complete.format(level, level+1))
    while matrix_complete:
        level += 1
        if empty_place < 100000:
            await db.update_clone_level(empty_place, level)
        else:
            await db.update_matrix_level(empty_place_id, level, 'sotka')
        new_empty_place = await db.get_empty_place_from_sotka(level, inviter, callback.from_user.id)
        if new_empty_place < 100000:
            new_empty_place_id = await db.get_user_by_clone(new_empty_place)
        else:
            new_empty_place_id = new_empty_place
        await db.add_user_to_sotka_matrix(level, new_empty_place, empty_place)
        last_filled_column = await db.get_last_filled_column_sotka(new_empty_place, level)
        matrix_complete = await db.is_sotka_matrix_complete(new_empty_place, level)
        if matrix_complete and level != 10:
            await bot.send_message(new_empty_place_id, messages.sotka_complete.format(level - 1, level))
        empty_place = new_empty_place
        empty_place_id = new_empty_place_id
        if last_filled_column:
            rewards = config.sotka_rewards.get(level)
            rewards = rewards[last_filled_column]
            for r in rewards:
                reward = r.split('_')
                try:
                    if reward[0] == 'cum':
                        await db.increase_classic_cum_balance(new_empty_place, int(reward[1]))
                        await bot.send_message(new_empty_place_id, messages.sotka_place_closed_cum.format(level, reward[1]))
                    elif reward[0] == 'draw':
                        await db.increase_classic_balance(new_empty_place_id, int(reward[1]))
                        message = messages.sotka_place_closed_draw.format(level, reward[1])
                        await send_payment_message(new_empty_place_id, 'sotka', reward[1], message)
                    elif reward[0] == 'inv':
                        inviter = await db.get_referrer(new_empty_place_id)
                        await db.increase_classic_balance(inviter, int(reward[1]))
                        message = messages.sotka_place_closed_draw.format(level, reward[1])
                        await send_payment_message(new_empty_place_id, 'sotka', reward[1], message)
                    elif reward[0] == 'clone' and len(rewards) == 2:
                        clone_id = await db.add_clone(user_id=new_empty_place_id, matrix_type='sotka', matrix_level=1)
                        empty_place = await db.get_empty_place_from_sotka(1, inviter, callback.from_user.id)
                        await db.add_user_to_sotka_matrix(1, empty_place, clone_id)
                        await bot.send_message(empty_place, messages.sotka_place_closed_clone.format(level))
                    elif reward[2] == 'j':
                        clone_id = await db.add_clone(user_id=empty_place_id, matrix_type='classic', matrix_level=1)
                        await db.update_matrix_level(empty_place_id, 1, 'classic')
                        empty_place = await db.get_empty_place(1, 'classic')
                        if empty_place < 100000:
                            empty_place_id = await db.get_user_by_clone(empty_place)
                        else:
                            empty_place_id = empty_place
                        await db.add_user_to_classic_matrix(1, empty_place, clone_id)
                        await bot.send_message(empty_place_id, messages.sotka_place_closed_clone_j.format(level))
                        await closed_place_check(empty_place, 'classic', 1, callback)
                    elif reward[0] == 'box':
                        await db.add_money_to_box(int(reward[1]))
                        await bot.send_message(new_empty_place_id, messages.sotka_place_closed_box.format(level, data['price']))
                    elif reward[0] == 'end':
                        referrals = await db.get_active_referrals(empty_place_id)
                        if len(referrals) >= 5:
                            money = await db.get_money_from_box()
                            money_per_user = money // len(referrals)
                            for i in referrals:
                                await db.increase_classic_balance(i['user_id'], money_per_user)
                                message = messages.sotka_place_closed_draw.format(reward[1])
                                await send_payment_message(i['user_id'], 'sotka', reward[1], message)
                except IndexError:
                    pass
    await user_states.wait_for_buy_sotka.set()
    await callback.message.edit_caption(messages.clone_bought.format(data['level_buy']),
                                        reply_markup=kb.buy_sotka_clone_kb(data['price'], data['matrix_type'],
                                                                               level, True))


@dp.callback_query_handler(text='confirm_buy', state=user_states.confirm_sotka_buy)
async def sotka_matrix_levels(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.edit_reply_markup(reply_markup=None)
    data = await state.get_data()
    level = int(data['level_buy'])
    inviter = await db.get_referrer(callback.from_user.id)
    empty_place = await db.get_empty_place_from_sotka(level, inviter, callback.from_user.id)
    if empty_place < 100000:
        empty_place_id = await db.get_user_by_clone(empty_place)
    else:
        empty_place_id = empty_place
    await db.add_user_to_sotka_matrix(level, empty_place, callback.from_user.id)
    await db.update_user_after_buy(callback.from_user.id, data['level_buy'], data['price'], 'sotka')
    await bot.send_message(config.forward_ch, messages.clone_log_message('sotka', level, callback.from_user.id,
                                                                         callback.from_user.username, False))

    partner_dict = config.sotka_rewards.get(level)
    partner = await db.get_last_filled_column_sotka(empty_place, level)
    rewards = partner_dict.get(partner)
    for r in rewards:
        try:
            temp_rewards = r.split('_')
            if temp_rewards[0] == 'cum':
                await db.increase_classic_cum_balance(empty_place_id, int(temp_rewards[1]))
                await bot.send_message(empty_place_id, messages.sotka_place_closed_cum.format(level, temp_rewards[1]))
            elif temp_rewards[0] == 'draw':
                await db.increase_classic_balance(empty_place_id, int(temp_rewards[1]))
                message = messages.sotka_place_closed_draw.format(level, temp_rewards[1])
                await send_payment_message(empty_place_id, 'sotka', temp_rewards[1], message)
            elif temp_rewards[0] == 'inv':
                await db.increase_classic_balance(inviter, int(temp_rewards[1]))
                await bot.send_message(inviter, messages.sotka_place_closed_draw.format(level, temp_rewards[1]))
            elif temp_rewards[0] == 'clone' and len(temp_rewards) == 2:
                clone_id = await db.add_clone(user_id=empty_place_id, matrix_type='sotka', matrix_level=1)

                empty_place_c = await db.get_empty_place_from_sotka(1, empty_place_id, callback.from_user.id)
                await db.add_user_to_sotka_matrix(1, empty_place_c, clone_id)
                if empty_place_c < 100000:
                    empty_place_c_id = await db.get_user_by_clone(empty_place_c)
                else:
                    empty_place_c_id = empty_place_c
                await bot.send_message(empty_place_id, messages.sotka_place_closed_clone.format(level))
            elif temp_rewards[2] == 'j':
                clone_id = await db.add_clone(user_id=empty_place_id, matrix_type='classic', matrix_level=1)
                await db.update_matrix_level(empty_place_id, 1, 'classic')
                empty_place_j = await db.get_empty_place(1, 'classic')
                if empty_place_j < 100000:
                    empty_place_id_j = await db.get_user_by_clone(empty_place_j)
                else:
                    empty_place_id_j = empty_place
                await db.add_user_to_classic_matrix(1, empty_place_j, clone_id)
                await bot.send_message(empty_place_id_j, messages.sotka_place_closed_clone_j.format(level))
                await closed_place_check(empty_place_j, 'classic', 1, callback)
            elif temp_rewards[0] == 'box':
                await db.add_money_to_box(int(temp_rewards[1]))
                await bot.send_message(empty_place_id, messages.sotka_place_closed_box.format(level, data['price']))
            elif temp_rewards[0] == 'end':
                referrals = await db.get_active_referrals(empty_place_id)
                if len(referrals) >= 3:
                    money = await db.get_money_from_box()
                    money_per_user = money // len(referrals)
                    message = messages.sotka_box_destroy.format(money_per_user)
                    for i in referrals:
                        await db.increase_classic_balance(i['user_id'], money_per_user)
                        await send_payment_message(i['user_id'], 'sotka', money_per_user, message)
                        await asyncio.sleep(1)
        except IndexError:
            pass
    matrix_complete = await db.is_sotka_matrix_complete(empty_place, level)
    if matrix_complete:
        await db.update_matrix_level(empty_place, level + 1, 'sotka')
        new_empty_place = await db.get_empty_place_from_sotka(level + 1, inviter, callback.from_user.id)
        if new_empty_place < 100000:
            new_empty_place_id = await db.get_user_by_clone(new_empty_place)
        else:
            new_empty_place_id = new_empty_place
        await db.add_user_to_sotka_matrix(1, new_empty_place, empty_place)
        await db.decrease_classic_cum_balance(new_empty_place, config.sotka_martix_config.get(level + 1))
        if level != 10:
            await bot.send_message(new_empty_place_id, messages.sotka_complete.format(level,
                                                                            level + 1))
    await user_states.wait_for_buy_sotka.set()
    await callback.message.edit_caption(messages.bought_message.format(data['level_buy']),
                                        reply_markup=kb.buy_sotka_clone_kb(data['price'], 'sotka',
                                                                     data['level_buy'], True))


@dp.callback_query_handler(text='matrix')
async def matrix_menu(callback: types.CallbackQuery):
    with open(config.matrix_image, 'rb') as file:
        await callback.message.edit_media(types.input_media.InputMediaPhoto(file), reply_markup=kb.matrix_kb())


@dp.callback_query_handler(text=['demo_matrix', 'classic_matrix'])
async def matrix(callback: types.CallbackQuery):
    if callback.data == 'demo_matrix':
        await callback.message.edit_reply_markup(kb.matrix_levels_kb('demo'))
        await callback.message.edit_caption(messages.demo_message, reply_markup=kb.matrix_levels_kb('demo'))
    else:
        await callback.message.edit_reply_markup(kb.matrix_levels_kb('classic'))
        await callback.message.edit_caption(messages.classic_message, reply_markup=kb.matrix_levels_kb('classic'))


@dp.callback_query_handler(lambda c: c.data.startswith('demo'))
async def demo_matrix_levels(callback: types.CallbackQuery, state: FSMContext):
    matrix_type, level = callback.data.split('_')[0], callback.data.split('_')[2]
    user_level = await db.get_demo_level(callback.from_user.id)
    level = int(level)
    if level == 1:
        message = messages.first_level_demo.format(config.demo_matrix_config.get(level))
        image = config.first_level_demo_image
    elif level == 2:
        message = messages.tripple_level_demo.format(config.demo_matrix_config.get(level), level)
        image = config.second_level_demo_image
    elif level == 3:
        message = messages.double_level_demo.format(config.demo_matrix_config.get(level), level)
        image = config.third_level_demo_image
    elif level == 4:
        message = messages.tripple_level_demo.format(config.demo_matrix_config.get(level), level)
        image = config.fourth_level_demo_image
    else:
        message = messages.double_level_demo.format(config.demo_matrix_config.get(level), level)
        image = config.fifth_level_demo_image
    with open(image, 'rb') as file:
        await callback.message.edit_media(types.input_media.InputMediaPhoto(file))
    price = config.demo_matrix_config.get(int(level))
    user_exists = await db.is_user_exists_in_demo_matrix(callback.from_user.id, int(level))
    matrix_complete = await db.is_demo_matrix_complete(callback.from_user.id, int(level))
    if user_exists and not matrix_complete:
        await callback.message.edit_caption(message, reply_markup=kb.buy_clone_kb(price, matrix_type, level, True))
    elif matrix_complete:
        await callback.message.edit_caption(message, reply_markup=kb.buy_clone_kb(price, matrix_type, level, True))
    elif level > user_level and level != 1:
        await callback.message.edit_caption(message, reply_markup=kb.buy_kb(allow_buy=False))
    else:
        await callback.message.edit_caption(message, reply_markup=kb.buy_kb(allow_buy=True))
    async with state.proxy() as data:
        data['level_buy'] = int(level)
        data['price'] = price
        data['matrix_type'] = matrix_type
    await user_states.wait_for_buy.set()


@dp.callback_query_handler(lambda c: c.data.startswith('classic'))
async def classic_matrix_level(callback: types.CallbackQuery, state: FSMContext):
    matrix_type, level = callback.data.split('_')[0], callback.data.split('_')[2]
    user_level = await db.get_demo_level(callback.from_user.id)
    level = int(level)
    if level == 1:
        message = messages.first_level_classic.format(config.classic_matrix_config.get(level))
        image = config.first_level_classic_image
    elif level == 2:
        message = messages.triple_level_classic.format(level, config.classic_matrix_config.get(level))
        image = config.second_level_classic_image
    elif level == 3:
        message = messages.double_level_classic.format(level, config.classic_matrix_config.get(level))
        image = config.third_level_classic_image
    elif level == 4:
        message = messages.triple_level_classic.format(level, config.classic_matrix_config.get(level))
        image = config.fourth_level_classic_image
    else:
        message = messages.double_level_classic.format(level, config.classic_matrix_config.get(level))
        image = config.fifth_level_classic_image
    with open(image, 'rb') as file:
        await callback.message.edit_media(types.input_media.InputMediaPhoto(file))
    price = config.classic_matrix_config.get(int(level))
    user_exists = await db.is_user_exists_in_classic_matrix(callback.from_user.id, int(level))
    matrix_complete = await db.is_classic_matrix_complete(callback.from_user.id, int(level))
    if user_exists and not matrix_complete:
        await callback.message.edit_caption(message, reply_markup=kb.buy_clone_kb(price, matrix_type, level, True))
    elif matrix_complete:
        await callback.message.edit_caption(message, reply_markup=kb.buy_clone_kb(price, matrix_type, level, True))
    elif level > user_level and level != 1:
        await callback.message.edit_caption(message, reply_markup=kb.buy_classic_kb(allow_buy=False))
    else:
        await callback.message.edit_caption(message, reply_markup=kb.buy_classic_kb(allow_buy=True))
    async with state.proxy() as data:
        data['level_buy'] = int(level)
        data['price'] = price
        data['matrix_type'] = matrix_type
    await user_states.wait_for_buy.set()


@dp.callback_query_handler(text='buy_level', state=user_states.wait_for_buy)
async def buy_level(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_balance = await db.get_user_balance(callback.from_user.id, data['matrix_type'])
    if user_balance < data['price']:
        await callback.message.edit_caption(messages.not_enough_cash_message,
                                            reply_markup=kb.start_kb(callback.from_user.id))
        await state.finish()
    else:
        await callback.message.edit_caption(messages.confrim_buy_demo_message.format(data['level_buy']),
                                            reply_markup=kb.confirm_buy_kb())
        await user_states.confirm_buy.set()


@dp.callback_query_handler(text='buy_level_classic', state=user_states.wait_for_buy)
async def buy_level(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    user_balance = await db.get_user_balance(callback.from_user.id, data['matrix_type'])
    if user_balance < data['price']:
        await callback.message.edit_caption(messages.not_enough_cash_message,
                                            reply_markup=kb.start_kb(callback.from_user.id))
        await state.finish()
    else:
        await callback.message.edit_caption(messages.confirm_buy_classic_message.format(data['level_buy']),
                                            reply_markup=kb.confirm_buy_kb())
        await user_states.confirm_buy.set()


@dp.callback_query_handler(text='confirm_buy', state=user_states.confirm_buy)
async def buy_level(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if data['matrix_type'] == 'demo':
        user_id = await db.get_empty_place(int(data['level_buy']), 'demo')
        if user_id < 100000:
            place_id = await db.get_user_by_clone(user_id)
            place_name = await bot.get_chat(place_id)
            clone_number = await db.get_clone_number(user_id)
        else:
            place_id = user_id
            place_name = await bot.get_chat(place_id)
            clone_number = -1
        await db.add_user_to_demo_matrix(int(data['level_buy']), user_id,
                                         callback.from_user.id)
        await db.update_user_after_buy(callback.from_user.id, data['level_buy'], data['price'], 'demo')
        partner_dict = config.demo_rewards.get(int(data['level_buy']))
        partner = await db.get_last_filled_column(user_id, int(data['level_buy']), 'demo')
        await bot.send_message(config.forward_ch, messages.clone_log_message('demo', data['level_buy'], callback.from_user.id,
                                                                             callback.from_user.username, False))
        await bot.send_message(config.forward_ch, messages.clone_set_message('demo', data['level_buy'], callback.from_user.id,
                                                                             callback.from_user.username,
                                                                             user_id, place_name.username,
                                                                             clone_number))

        rewards = partner_dict.get(partner)
        for r in rewards:
            temp_rewards = r.split('_')
            if temp_rewards[0] == 'cum':
                await db.increase_demo_cum_balance(user_id, int(temp_rewards[1]))
            elif temp_rewards[0] == 'draw':
                await db.increase_demo_balance(user_id, int(temp_rewards[1]))
            elif temp_rewards[0] == 'inv':
                inviter = await db.get_referrer(user_id)
                await db.increase_demo_balance(inviter, int(temp_rewards[1]))
            elif temp_rewards[0] == 'adm':
                await db.increase_demo_balance(config.admins[0], int(temp_rewards[1]))
            elif temp_rewards[0] == 'clone':
                clone_id = await db.add_clone(user_id=user_id, matrix_type=data['matrix_type'], matrix_level=1)
                empty_place = await db.get_empty_place(1, 'demo')
                await db.add_user_to_demo_matrix(1, empty_place, clone_id)
        matrix_complete = await db.is_demo_matrix_complete(user_id, data['level_buy'])
        if matrix_complete:
            await db.update_matrix_level(user_id, int(data['level_buy'])+1, 'demo')
            new_empty_place = await db.get_empty_place(int(data['level_buy'])+1, 'demo')
            await db.add_user_to_demo_matrix(1, new_empty_place, user_id)
            await db.decrease_demo_cum_balance(user_id, config.demo_matrix_config.get(int(data['level_buy'])+1))
            await bot.send_message(user_id, messages.matrix_complete.format(int(data['level_buy']),
                                                                            int(data['level_buy'])+1), reply_markup=kb.start_kb(callback.from_user.id))
        clone_date = await db.get_clone_date(callback.from_user.id)
        if clone_date < datetime.today():
            await callback.message.edit_caption(messages.bought_message.format(data['level_buy']),
                                                reply_markup=kb.buy_clone_kb(data['price'], data['matrix_type'], data['level_buy'], True))
        else:
            await callback.message.edit_caption(messages.bought_message.format(data['level_buy']),
                                                reply_markup=kb.buy_clone_kb(data['price'], data['matrix_type'], data['level_buy'], False))

        await bot.send_message(user_id, messages.demo_place_closed_cum.format(data['level_buy'], data['price']))
    else:
        user_id = await db.get_empty_place(int(data['level_buy']), 'classic')
        await db.add_user_to_classic_matrix(int(data['level_buy']), user_id, callback.from_user.id)
        await db.update_user_after_buy(callback.from_user.id, data['level_buy'], data['price'], 'classic')
        if user_id < 100000:
            place_id = await db.get_user_by_clone(user_id)
            place_name = await bot.get_chat(place_id)
            clone_number = await db.get_clone_number(user_id)
        else:
            place_id = user_id
            place_name = await bot.get_chat(place_id)
            clone_number = -1
        await bot.send_message(config.forward_ch, messages.clone_log_message('classic', data['level_buy'], callback.from_user.id,
                                                                             callback.from_user.username, False))
        await bot.send_message(config.forward_ch, messages.clone_set_message('classic', data['level_buy'], callback.from_user.id,
                                                                             callback.from_user.username,
                                                                             user_id, place_name.username,
                                                                             clone_number))

        partner_dict = config.classic_rewards.get(int(data['level_buy']))
        partner = await db.get_last_filled_column(user_id, int(data['level_buy']), 'classic')
        rewards = partner_dict.get(partner)
        for r in rewards:
            temp_rewards = r.split('_')
            if temp_rewards[0] == 'cum':
                await db.increase_classic_cum_balance(user_id, int(temp_rewards[1]))
            elif temp_rewards[0] == 'draw':
                await db.increase_classic_balance(user_id, int(temp_rewards[1]))
            elif temp_rewards[0] == 'inv':
                inviter = await db.get_referrer(user_id)
                await db.increase_classic_balance(inviter, int(temp_rewards[1]))
            elif temp_rewards[0] == 'adm':
                await db.increase_classic_balance(config.admins[0], int(temp_rewards[1]))
            elif temp_rewards[0] == 'clone':
                clone_id = await db.add_clone(user_id=user_id, matrix_type=data['matrix_type'], matrix_level=1)
                empty_place = await db.get_empty_place(1, 'classic')
                await db.add_user_to_classic_matrix(1, empty_place, clone_id)
        matrix_complete = await db.is_classic_matrix_complete(user_id, data['level_buy'])
        if matrix_complete:
            new_empty_place = await db.get_empty_place(int(data['level_buy'])+1, 'classic')
            await db.add_user_to_classic_matrix(1, new_empty_place, user_id)
            await db.update_matrix_level(user_id, int(data['level_buy']) + 1, 'classic')
            await db.decrease_classic_cum_balance(user_id, config.classic_matrix_config.get(int(data['level_buy']) + 1))
            await bot.send_message(user_id, messages.matrix_complete.format(int(data['level_buy']),
                                                                            int(data['level_buy']) + 1))
        clone_date = await db.get_clone_date(callback.from_user.id)
        if clone_date < datetime.today():
            await callback.message.edit_caption(messages.bought_message.format(data['level_buy']),
                                                reply_markup=kb.buy_clone_kb(data['price'], data['matrix_type'],
                                                                             data['level_buy'], True))
        else:
            await callback.message.edit_caption(messages.bought_message.format(data['level_buy']),
                                                reply_markup=kb.buy_clone_kb(data['price'], data['matrix_type'],
                                                                             data['level_buy'], False))

        await bot.send_message(user_id, messages.classic_place_closed_cum.format(data['level_buy'], data['price']))
    await user_states.wait_for_buy.set()


@dp.callback_query_handler(lambda c: c.data.startswith('buy_clone'), state=user_states.wait_for_buy)
async def buy_clone(callback: types.CallbackQuery, state: FSMContext):
    callback_data = callback.data.split('_')
    async with state.proxy() as data:
        data['matrix_type'] = callback_data[2]
        data['matrix_level'] = int(callback_data[3])
        data['price'] = int(callback_data[4])
    user_balance = await db.get_user_balance(callback.from_user.id, callback_data[2])
    clone_buy_date = await db.get_clone_date(callback.from_user.id)
    if int(callback_data[3]) > user_balance:
        await callback.message.edit_caption(messages.not_enough_cash_message, reply_markup=kb.start_kb(callback.from_user.id))
        await state.finish()
    elif clone_buy_date > datetime.today():
        await callback.message.edit_caption(messages.date_restriction_for_clone, reply_markup=kb.start_kb(callback.from_user.id))
        await state.finish()
    else:
        if callback_data[2] == 'demo':
            matrix_type = 'ДЕМО'
        else:
            matrix_type = 'Живой'
        await callback.message.edit_caption(messages.clone_confirm_buy_message.format(
            callback_data[4], callback_data[3], matrix_type), reply_markup=kb.confirm_buy_kb())
        await user_states.confirm_clone_buy.set()


@dp.callback_query_handler(text='confirm_buy', state=user_states.confirm_clone_buy)
async def confirm_buy_clone(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    level = data['level_buy']
    clone_id = await db.add_clone(callback.from_user.id, data['matrix_type'], 1)
    empty_place = await db.get_empty_place(1, data['matrix_type'])
    if empty_place < 100000:
        empty_place_id = await db.get_user_by_clone(empty_place)
    else:
        empty_place_id = empty_place
    if data['matrix_type'] == 'demo':
        await db.add_user_to_demo_matrix(1, empty_place, clone_id)
        last_filled_column = await db.get_last_filled_column(empty_place, 1, 'demo')
        rewards = config.demo_rewards.get(1)
        reward = rewards[last_filled_column][0].split('_')
        await bot.send_message(empty_place_id, messages.demo_place_closed_cum.format(1, reward[1]))
        await db.increase_demo_cum_balance(empty_place, int(reward[1]))
        matrix_complete = await db.is_demo_matrix_complete(empty_place, level)
        await callback.message.edit_caption(messages.clone_bought.format(level), reply_markup=kb.matrix_levels_kb('demo'))
        if matrix_complete:
            await bot.send_message(empty_place_id, messages.matrix_complete.format(level, level+1))
        while matrix_complete:
            level += 1
            if empty_place < 100000:
                await db.update_clone_level(empty_place, level)
            else:
                await db.update_matrix_level(empty_place, level, 'demo')
            new_empty_place = await db.get_empty_place(level, 'demo')
            if new_empty_place < 100000:
                new_empty_place_id = await db.get_user_by_clone(new_empty_place)
            else:
                new_empty_place_id = new_empty_place
            await db.add_user_to_demo_matrix(level, new_empty_place, empty_place)
            last_filled_column = await db.get_last_filled_column(new_empty_place, level, 'demo')
            matrix_complete = await db.is_demo_matrix_complete(new_empty_place, level)
            if matrix_complete:
                await bot.send_message(new_empty_place_id, messages.matrix_complete.format(level, level + 1))
            empty_place = new_empty_place
            if last_filled_column:
                rewards = config.demo_rewards.get(level)
                rewards = rewards[last_filled_column]
                for r in rewards:
                    reward = r.split('_')
                    if reward[0] == 'cum':
                        await db.increase_demo_cum_balance(new_empty_place, int(reward[1]))
                        await bot.send_message(new_empty_place_id, messages.demo_place_closed_cum.format(1, reward[1]))
                    elif reward[0] == 'clone':
                        clone = await db.add_clone(new_empty_place_id, 'demo', 1)
                        clone_empty_place = await db.get_empty_place(1, 'demo')
                        await db.add_user_to_demo_matrix(1, clone_empty_place, clone)
                    elif reward[0] == 'draw':
                        await db.increase_demo_balance(new_empty_place_id, int(reward[1]))
                        message = messages.demo_bal_increased.format(reward[1])
                        await send_payment_message(new_empty_place_id, 'demo', reward[1], message)
                    elif reward[0] == 'inv':
                        inviter = await db.get_referrer(new_empty_place_id)
                        await db.increase_demo_balance(inviter, int(reward[1]))
                        message = messages.demo_bal_increased.format(reward[1])
                        await send_payment_message(inviter, 'demo', reward[1], message)
                    elif reward[0] == 'adm':
                        await db.increase_demo_balance(config.admins[0], int(reward[1]))
                        message = messages.demo_bal_increased.format(reward[1])
                        await send_payment_message(new_empty_place_id, 'demo', reward[1], message)

            await bot.send_message(empty_place_id, messages.matrix_complete.format(level-1, level))

    elif data['matrix_type'] == 'classic':
        await db.add_user_to_classic_matrix(1, empty_place, clone_id)
        last_filled_column = await db.get_last_filled_column(empty_place, 1, 'classic')
        rewards = config.classic_rewards.get(1)
        reward = rewards[last_filled_column][0].split('_')
        await db.increase_classic_cum_balance(empty_place, int(reward[1]))
        await bot.send_message(empty_place_id, messages.classic_place_closed_cum.format(1, reward[1]))
        await bot.send_message(config.forward_ch, messages.clone_log_message('classic', level, callback.from_user.id,
                                                                             callback.from_user.username, True))
        place_name = await bot.get_chat(empty_place_id)
        clone_number = await db.get_clone_number(empty_place)
        await bot.send_message(config.forward_ch, messages.clone_set_message('classic', level, callback.from_user.id,
                                                                             callback.from_user.username, empty_place_id, place_name.username, clone_number))

        matrix_complete = await db.is_classic_matrix_complete(empty_place, level)
        await callback.message.edit_caption(messages.clone_bought.format(level), reply_markup=kb.matrix_levels_kb('classic'))
        if matrix_complete:
            await bot.send_message(empty_place_id, messages.matrix_complete.format(level, level+1))
        while matrix_complete:
            level += 1
            await db.update_matrix_level(empty_place, level, 'classic')
            new_empty_place = await db.get_empty_place(level, 'classic')
            if new_empty_place < 100000:
                new_empty_place_id = await db.get_user_by_clone(new_empty_place)
            else:
                new_empty_place_id = new_empty_place
            await db.add_user_to_classic_matrix(level, new_empty_place, empty_place)
            last_filled_column = await db.get_last_filled_column(new_empty_place, level, 'classic')
            matrix_complete = await db.is_classic_matrix_complete(new_empty_place, level)
            if matrix_complete:
                await bot.send_message(new_empty_place_id, messages.matrix_complete.format(level, level+1))
            empty_place = new_empty_place
            if last_filled_column:
                rewards = config.classic_rewards.get(level)
                rewards = rewards[last_filled_column]
                for r in rewards:
                    reward = r.split('_')
                    if reward[0] == 'cum':
                        await db.increase_classic_cum_balance(new_empty_place, int(reward[1]))
                        await bot.send_message(new_empty_place_id, messages.classic_place_closed_cum.format(1, reward[1]))
                    elif reward[0] == 'clone':
                        clone = await db.add_clone(new_empty_place_id, 'classic', 1)
                        clone_empty_place = await db.get_empty_place(1, 'classic')
                        await db.add_user_to_classic_matrix(1, clone_empty_place, clone)
                    elif reward[0] == 'draw':
                        await db.increase_classic_balance(new_empty_place_id, int(reward[1]))
                        message = messages.classic_bal_increased.format(reward[1])
                        await send_payment_message(new_empty_place_id, 'classic', reward[1], message)
                    elif reward[0] == 'inv':
                        inviter = await db.get_referrer(new_empty_place_id)
                        await db.increase_classic_balance(inviter, int(reward[1]))
                        message = messages.classic_bal_increased.format(reward[1])
                        await send_payment_message(new_empty_place_id, 'classic', reward[1], message)
                    elif reward[0] == 'adm':
                        await db.increase_classic_balance(config.admins[0], int(reward[1]))
                        message = messages.classic_bal_increased.format(reward[1])
                        await send_payment_message(new_empty_place_id, 'classic', reward[1], message)
                await bot.send_message(empty_place_id, messages.matrix_complete.format(level-1, level))
    await state.finish()


@dp.callback_query_handler(text='show_board', state='*')
async def show_board(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    inviter = await db.get_topper_place(callback.from_user.id, data['matrix_type'], data['level_buy'])
    if inviter < 100000:
        inviter = await db.get_user_by_clone(inviter)
    else:
        inviter = inviter
    user_avatar_path = await get_user_photo(inviter)
    inviter = await bot.get_chat(inviter)
    partners = await db.get_partners_from_matrix(data['level_buy'], inviter.id, data['matrix_type'])
    partners_for_image = await convert_partners(partners)
    partners_for_image.insert(0, [inviter.username, inviter.id, user_avatar_path, False])
    next_partners = []
    for i in partners:
        for k in i:
            next_partners += await db.get_partners_from_matrix(data['level_buy'], k, data['matrix_type'])
    print(next_partners, partners, sep='\n')
    closed_places = await db.get_closed_places(callback.from_user.id, data['matrix_type'], data['level_buy'])
    next_partners = await convert_partners(next_partners)
    worker = ImageWorker(data['level_buy'], data['matrix_type'], partners_for_image, closed_places)
    image = worker.create_image()
    worker.set_positions(image, next_partners)
    clone_date = await db.get_clone_date(callback.from_user.id)
    with open(image, 'rb') as f:
        if clone_date < datetime.today():
            await bot.send_photo(callback.from_user.id, f, reply_markup=kb.buy_clone_kb(data['matrix_type'], data['level_buy'], data['price'], True)) # !!!
        else:
            await bot.send_photo(callback.from_user.id, f, reply_markup=kb.buy_clone_kb(data['matrix_type'], data['level_buy'], data['price'], False)) # !!!

    remove_file(image)
    for p in partners_for_image:
        if p is None:
            continue
        if p[2] is not None:
            remove_file(p[2])
    for k in next_partners:
        if k is None:
            continue
        if k[2] is not None:
            remove_file(k[2])


@dp.callback_query_handler(text='referral_mailing')
async def referral_mailing(callback: types.CallbackQuery):
    await callback.message.answer('Введите сообщение или нажмите отменить', reply_markup=kb.cancel_kb())
    await user_states.get_users_mailing_message.set()


@dp.message_handler(state=user_states.get_users_mailing_message)
async def get_user_message(message: types.Message, state: FSMContext):
    referrals = await db.get_all_referrals(message.from_user.id)
    result = []
    for r in referrals:
        result.append(r['referral_id'])
    await mailing(result, message.text)
    with open(config.account_image, 'rb') as file:
        await bot.send_photo(message.from_user.id, file, caption='Рассылка успешно завершена',
                             reply_markup=kb.acc_kb())
    await state.finish()


@dp.callback_query_handler(lambda c: c.data.startswith('choose_clone'), state='*')
async def choose_clone(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    clone_exists = await db.get_clones(data['matrix_type'], data['level_buy'], callback.from_user.id, 10)
    if not clone_exists:
        with open(config.matrix_image, 'rb') as f:
            await callback.message.edit_media(types.input_media.InputMediaPhoto(f))
        if data['matrix_type'] in ('demo', 'classic'):
            await callback.message.edit_caption(messages.no_clones_message, reply_markup=kb.matrix_levels_kb(data['matrix_type']))
            await user_states.wait_for_buy.set()
        else:
            await callback.message.edit_caption(messages.no_clones_message,
                                                reply_markup=kb.buy_sotka_clone_kb(data['price'], data['matrix_type'], data['level_buy'],
                                                                                   True))
            await user_states.wait_for_buy_sotka.set()
    else:
        await callback.message.edit_reply_markup(reply_markup=kb.clones_kb(clone_exists))
        async with state.proxy() as data:
            data['page_number'] = 1
        await user_states.clone_choose_state.set()


@dp.callback_query_handler(text=['next_page', 'prev_page', 'back_to_levels'], state=user_states.clone_choose_state)
async def clone_pages(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    page_num = data['page_number']
    if callback.data == 'next_page':
        page_num += 1
    elif callback.data == 'prev_page':
        if page_num > 2:
            page_num -= 1
    elif callback.data == 'back_to_levels':
        clone_date = await db.get_clone_date(callback.from_user.id)
        if clone_date < datetime.today():
            await callback.message.edit_reply_markup(reply_markup=kb.buy_clone_kb(data["price"], data['matrix_type'],
                                                                                  data['level_buy'], True))
        else:
            await callback.message.edit_reply_markup(reply_markup=kb.buy_clone_kb(data["price"], data['matrix_type'],
                                                                                  data['level_buy'], False))
        await user_states.wait_for_buy.set()
        return
    limit = page_num * 10
    clones = await db.get_clones(data['matrix_type'], data['level_buy'], callback.from_user.id, limit)
    if clones[limit-10::]:
        try:
            await callback.message.edit_reply_markup(reply_markup=kb.clones_kb(clones[limit-10::]))
            async with state.proxy() as data:
                data['page_number'] = page_num
        except MessageNotModified:
            pass


@dp.callback_query_handler(lambda c: c.data.startswith('clone_'), state=user_states.clone_choose_state)
async def choose_clone(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    clone_id = int(callback.data.split('_')[1])
    level = data['level_buy']
    matrix_type = data['matrix_type']
    top_place = await db.get_topper_place(clone_id, matrix_type, level)
    if top_place < 100000:
        top_place_id = await db.get_user_by_clone(top_place)
    else:
        top_place_id = top_place
    user_avatar_path = await get_user_photo(top_place_id)
    top_place = await bot.get_chat(top_place_id)
    partners = await db.get_partners_from_matrix(level, top_place.id, matrix_type)
    partners_for_image = await convert_partners(partners)
    partners_for_image.insert(0, [top_place.username, top_place.id, user_avatar_path, False])
    next_partners = []
    for p in partners:
        for k in p:
            next_partners += await db.get_partners_from_matrix(level, k, matrix_type)
    closed_places = await db.get_closed_places(clone_id, matrix_type, level)
    next_partners = await convert_partners(next_partners)
    worker = ImageWorker(level, matrix_type, partners_for_image, closed_places)
    image = worker.create_image()
    worker.set_positions(image, next_partners)
    clone_date = await db.get_clone_date(callback.from_user.id)
    with open(image, 'rb') as f:
        if clone_date < datetime.today():
            await bot.send_photo(callback.from_user.id, f, reply_markup=kb.buy_clone_kb(data['matrix_type'], data['level_buy'], data['price'], True)) # !!!
        else:
            await bot.send_photo(callback.from_user.id, f, reply_markup=kb.buy_clone_kb(data['matrix_type'], data['level_buy'], data['price'], False)) # !!!
    await user_states.clone_choose_state.set()
    remove_file(image)
    for p in partners_for_image:
        if p is None:
            continue
        elif p[2] is not None:
            remove_file(p[2])
    for k in next_partners:
        if k is None:
            continue
        elif k[2] is not None:
            remove_file(k[2])


@dp.callback_query_handler(filters.IDFilter(user_id=config.admins), text='admin_panel')
async def admin_panel(callback: types.CallbackQuery):
    await callback.message.edit_reply_markup(reply_markup=kb.admin_kb())


@dp.callback_query_handler(filters.IDFilter(user_id=config.admins), text='admin_mailing')
async def admin_mailing(callback: types.CallbackQuery):
    await bot.send_message(callback.from_user.id, 'Введите ваше сообщение')
    await user_states.get_admin_mailing_message.set()


@dp.message_handler(filters.IDFilter(user_id=config.admins), state=user_states.get_admin_mailing_message)
async def admin_mailing(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['message'] = message.text
    await bot.send_message(message.from_user.id, f'Вы уверены что хотите отправить:\n\n {message.text}',
                           reply_markup=kb.confirm_mail_kb())
    await user_states.confirm_mailing.set()


@dp.callback_query_handler(filters.IDFilter(user_id=config.admins), state=user_states.confirm_mailing)
async def confirm_mailing(callback: types.CallbackQuery, state: FSMContext):
    if callback.data == 'confirm_mailing':
        data = await state.get_data()
        users = await db.get_all_users()
        for u in users:
            try:
                await bot.send_message(u['user_id'], data['message'], reply_markup=kb.start_kb(u['user_id']))
            except BotBlocked:
                logging.info(f'Bot was blocked by: {u}')
            await asyncio.sleep(0.5)
        await bot.send_message(callback.from_user.id, 'Рассылка завершена', reply_markup=kb.admin_kb())
        await state.finish()
    else:
        await state.finish()
        await callback.message.edit_reply_markup(reply_markup=kb.admin_kb())


async def mailing(user_list: list, message: str):
    for u in user_list:
        try:
            await bot.send_message(u, message)
        except BotBlocked:
            logging.warning(f'Bot was blocked by: {u}')
        await asyncio.sleep(0.5)


async def convert_partners(partners):
    partners_for_image = []
    counter = 1
    for k in partners:
        for p in k:
            if p:
                try:
                    partner = await bot.get_chat(p)
                    partner_photo = await bot.get_user_profile_photos(p)
                    is_clone = False
                except ChatNotFound:
                    clone_owner = await db.get_clone_from_matrix(p)
                    partner = await bot.get_chat(clone_owner)
                    partner_photo = await bot.get_user_profile_photos(clone_owner)
                    is_clone = True
                if partner_photo['photos']:
                    photo_path = f"sources/temp_images/{p}.jpg"
                    await bot.download_file_by_id(partner_photo['photos'][0][-1]['file_id'], photo_path)
                else:
                    photo_path = None
                if is_clone:
                    clone_number = await db.get_clone_number(p)
                else:
                    clone_number = None
                partners_for_image.append([partner.username, partner.id, photo_path, is_clone, clone_number])
                counter += 1
            else:
                partners_for_image.append(None)
    return partners_for_image


async def get_user_photo(user_id: int):
    user_avatar = await bot.get_user_profile_photos(user_id)
    if not user_avatar['photos']:
        user_avatar_path = None
    else:
        user_avatar = user_avatar['photos'][0]
        user_avatar_path = 'sources/temp_images/' + str(uuid4()) + '.jpg'
        await bot.download_file_by_id(user_avatar[0]['file_id'], user_avatar_path)
    return user_avatar_path


async def send_payment_message(user_id: int, matrix_type: str, payment: int, message: str):
    user_avatar = await get_user_photo(user_id)
    user_name = await bot.get_chat(user_id)
    total_earned = await db.get_total_earned(user_id)
    user_name = user_name.full_name
    photo = PaymentImage(user_avatar, user_name, matrix_type, payment, total_earned).create_image()
    with open(photo, 'rb') as f:
        await bot.send_photo(user_id, f, caption=message)
    with open(photo, 'rb') as f:
        await bot.send_photo(config.group_chat, f)
    remove_file(user_avatar)
    remove_file(photo)


async def closed_place_check(empty_place: int, matrix_type: str, level: int, callback: types.CallbackQuery):
    level = level
    if empty_place < 100000:
        empty_place_id = await db.get_user_by_clone(empty_place)
    else:
        empty_place_id = empty_place
    if matrix_type == 'classic':
        await db.update_matrix_level(empty_place, level, 'classic')
        new_empty_place = await db.get_empty_place(level, 'classic')
        if new_empty_place < 100000:
            new_empty_place_id = await db.get_user_by_clone(new_empty_place)
        else:
            new_empty_place_id = new_empty_place
        await db.add_user_to_classic_matrix(level, new_empty_place, empty_place)
        partner_dict = config.classic_rewards.get(level)
        partner = await db.get_last_filled_column(empty_place, level, 'classic')
        rewards = partner_dict.get(partner)
        matrix_complete = await db.is_classic_matrix_complete(new_empty_place, level)
        empty_place = new_empty_place
        empty_place_id = new_empty_place_id
        for r in rewards:
            reward = r.split('_')
            try:
                if reward[0] == 'cum':
                    await db.increase_classic_cum_balance(empty_place, int(reward[1]))
                    await bot.send_message(empty_place_id,
                                           messages.classic_place_closed_cum.format(level, reward[1]))
                elif reward[0] == 'clone':
                    clone = await db.add_clone(empty_place_id, 'classic', 1)
                    clone_empty_place = await db.get_empty_place(1, 'classic')
                    await db.add_user_to_sotka_matrix(1, clone_empty_place, clone)
                elif reward[0] == 'draw':
                    await db.increase_classic_balance(empty_place_id, int(reward[1]))
                    message = messages.classic_bal_increased.format(reward[1])
                    await send_payment_message(empty_place_id, 'classic', reward[1], message)
                elif reward[0] == 'inv':
                    inviter = await db.get_referrer(empty_place_id)
                    await db.increase_classic_balance(inviter, int(reward[1]))
                    message = messages.classic_bal_increased.format(reward[1])
                    await send_payment_message(empty_place_id, 'classic', reward[1], message)
            except IndexError:
                pass
            while matrix_complete:
                level += 1
                await db.update_matrix_level(empty_place, level, 'classic')
                new_empty_place = await db.get_empty_place(level, 'classic')
                if new_empty_place < 100000:
                    new_empty_place_id = await db.get_user_by_clone(new_empty_place)
                else:
                    new_empty_place_id = new_empty_place
                await db.add_user_to_classic_matrix(level, new_empty_place, empty_place)
                last_filled_column = await db.get_last_filled_column(new_empty_place, level, 'classic')
                matrix_complete = await db.is_classic_matrix_complete(new_empty_place, level)
                if matrix_complete:
                    await bot.send_message(new_empty_place_id, messages.matrix_complete.format(level, level + 1))
                empty_place = new_empty_place
                if last_filled_column:
                    rewards = config.classic_rewards.get(level)
                    rewards = rewards[last_filled_column]
                    for r in rewards:
                        reward = r.split('_')
                        if reward[0] == 'cum':
                            await db.increase_classic_cum_balance(new_empty_place, int(reward[1]))
                            await bot.send_message(new_empty_place_id,
                                                   messages.classic_place_closed_cum.format(1, reward[1]))
                        elif reward[0] == 'clone':
                            clone = await db.add_clone(new_empty_place_id, 'classic', 1)
                            clone_empty_place = await db.get_empty_place(1, 'classic')
                            await db.add_user_to_classic_matrix(1, clone_empty_place, clone)
                        elif reward[0] == 'draw':
                            await db.increase_classic_balance(new_empty_place_id, int(reward[1]))
                            message = messages.classic_bal_increased.format(reward[1])
                            await send_payment_message(new_empty_place_id, 'classic', reward[1], message)
                        elif reward[0] == 'inv':
                            inviter = await db.get_referrer(new_empty_place_id)
                            await db.increase_classic_balance(inviter, int(reward[1]))
                            message = messages.classic_bal_increased.format(reward[1])
                            await send_payment_message(new_empty_place_id, 'classic', reward[1], message)
                        elif reward[0] == 'adm':
                            await db.increase_classic_balance(config.admins[0], int(reward[1]))
                            message = messages.classic_bal_increased.format(reward[1])
                            await send_payment_message(new_empty_place_id, 'classic', reward[1], message)
                    await bot.send_message(empty_place_id, messages.matrix_complete.format(level - 1, level))
    else:
        pass



async def main():
    await db.create_pool()
    await db.create_tables()
    await dp.start_polling(bot)


if __name__ == '__main__':
    asyncio.get_event_loop().run_until_complete(main())
